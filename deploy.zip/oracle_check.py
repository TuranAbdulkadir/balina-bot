import oci
import os

key_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "oracle.pem")
config = {
    "user": "ocid1.user.oc1..aaaaaaaai4f4hxatemb2hgq7ljw6o36vcdbsgj5uie4w657e6tlbfxl5rtga",
    "fingerprint": "f9:87:50:4d:36:9f:4e:96:2b:03:d0:c1:d7:ee:7c:11",
    "tenancy": "ocid1.tenancy.oc1..aaaaaaaa6cpc6th6uhqxsqm6ycbd6ath3bjlon7b56mqdyer5lex3nets7ja",
    "region": "eu-frankfurt-1",
    "key_file": key_path
}

compute_client = oci.core.ComputeClient(config)
network_client = oci.core.VirtualNetworkClient(config)
comp_id = config["tenancy"]

instances = compute_client.list_instances(comp_id).data
for i in instances:
    if i.lifecycle_state == i.LIFECYCLE_STATE_RUNNING:
        try:
            vnics = compute_client.list_vnic_attachments(comp_id, instance_id=i.id).data
            for v in vnics:
                vnic = network_client.get_vnic(v.vnic_id).data
                print(f"[OCI] {i.display_name} -> {vnic.public_ip}")
        except Exception as e:
            print(f"Error checking {i.display_name}: {e}")
