import os
import re

for root, _, files in os.walk('.'):
    for f in files:
        if f.endswith('.py') and f not in ('logger_factory.py', 'patch_loggers.py', 'http_client.py', 'funding.py'):
            path = os.path.join(root, f)
            with open(path, 'r', encoding='utf-8') as file:
                content = file.read()
            original = content
            
            # Migrate Python's standard getLogger to aiologger wrapper
            content = re.sub(r'logging\.getLogger\(([\'\"][A-Za-z0-9_]+[\'\"])\)', r'get_logger(\1)', content)
            
            # If changed, ensure import exists
            if content != original:
                content = content.replace('import logging', 'from core.logger_factory import get_logger')
                
                # If there were multiple imports combined like import sys, logging -> won't match. 
                # Just add import manually at the top if missing
                if 'from core.logger_factory import get_logger' not in content:
                    content = "from core.logger_factory import get_logger\n" + content
                    
                with open(path, 'w', encoding='utf-8') as file:
                    file.write(content)
                print(f'Deep Patched {path}')
