import oci
import time
import requests
import os
from datetime import datetime

# ══════════════════════════════════════════════════════════════
# OLUMSUZ AVCI BOT v3.0 (FRANKFURT MULTI-CONFIG HUNTER)
# Free Tier ARM = SADECE HOME REGION (Frankfurt)
# Strateji: Farkli OCPU/RAM kombinasyonlari ile saldiri
# ══════════════════════════════════════════════════════════════

key_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "oracle.pem")

config = {
    "user": "ocid1.user.oc1..aaaaaaaai4f4hxatemb2hgq7ljw6o36vcdbsgj5uie4w657e6tlbfxl5rtga",
    "fingerprint": "f9:87:50:4d:36:9f:4e:96:2b:03:d0:c1:d7:ee:7c:11",
    "tenancy": "ocid1.tenancy.oc1..aaaaaaaa6cpc6th6uhqxsqm6ycbd6ath3bjlon7b56mqdyer5lex3nets7ja",
    "region": "eu-frankfurt-1",
    "key_file": key_path
}

# Sadece en buyuk konfigurasyonu hedefle (zaten 1CPU/1GB AMD var elimizde)
CONFIGS = [
    {"ocpus": 4.0, "memory": 24.0, "name": "4CPU-24GB"},
]

# Telegram .env ayarlarini parse et
TELEGRAM_BOT_TOKEN = None
TELEGRAM_CHAT_ID = None
try:
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    with open(env_path, "r") as f:
        for line in f:
            if line.startswith("TG_TOKEN="):
                TELEGRAM_BOT_TOKEN = line.strip().split("=")[1].strip("'\"")
            if line.startswith("TG_USER_ID="):
                TELEGRAM_CHAT_ID = line.strip().split("=")[1].strip("'\"")
except:
    pass

def send_telegram_alert(msg):
    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        try:
            requests.post(url, json={"chat_id": TELEGRAM_CHAT_ID, "text": msg}, timeout=10)
            print("[OK] Telegram mesaji gonderildi!")
        except Exception as e:
            print(f"[WARN] Telegram hatti basarisiz: {e}")

def hunt_for_server():
    try:
        oci.config.validate_config(config)
        print("[INFO] Oracle API Sifreleri Dogrulandi!")
        send_telegram_alert("🟢 Oracle Bulut Avcısı (4 Çekirdek - 24GB RAM) başarıyla başlatıldı! Stok yoklaması için devriye atılıyor...")
        print("[INFO] Free Tier ARM = SADECE Home Region (Frankfurt)")
        print(f"[INFO] {len(CONFIGS)} farkli konfigurasyonla saldiri yapilacak\n")

        compute_client = oci.core.ComputeClient(config)
        network_client = oci.core.VirtualNetworkClient(config)
        identity_client = oci.identity.IdentityClient(config)

        compartment_id = config["tenancy"]

        # AD'leri Bul
        ads = identity_client.list_availability_domains(compartment_id).data
        if not ads:
            print("[ERROR] Availability Domain bulunamadi!")
            return
        print(f"[INFO] {len(ads)} Availability Domain bulundu: {[a.name[-4:] for a in ads]}")

        # Subnet Bul
        subnets = network_client.list_subnets(compartment_id).data
        if not subnets:
            print("[ERROR] VCN/Subnet bulunamadi!")
            return
        subnet_id = subnets[0].id
        print(f"[INFO] Subnet: {subnet_id[:30]}...")

        # ARM Image Bul
        images = compute_client.list_images(
            compartment_id,
            operating_system="Canonical Ubuntu",
            operating_system_version="22.04",
            shape="VM.Standard.A1.Flex"
        ).data
        if not images:
            print("[ERROR] ARM Image bulunamadi!")
            return
        image_id = images[0].id
        print(f"[INFO] Image: {images[0].display_name}")

        print(f"\n{'='*60}")
        print(f"  ORACLE AVCI BOTU v3.0 - FRANKFURT MULTI-CONFIG")
        print(f"  Her 10 saniyede {len(ads)} AD x {len(CONFIGS)} config = {len(ads)*len(CONFIGS)} deneme/tur")
        print(f"{'='*60}\n")

        attempts = 0
        start_time = time.time()

        while True:
            for cfg in CONFIGS:
                for ad in ads:
                    attempts += 1
                    short_ad = ad.name[-4:]

                    request = oci.core.models.LaunchInstanceDetails(
                        compartment_id=compartment_id,
                        availability_domain=ad.name,
                        display_name=f"Balina-{cfg['name']}",
                        shape="VM.Standard.A1.Flex",
                        shape_config=oci.core.models.LaunchInstanceShapeConfigDetails(
                            ocpus=cfg["ocpus"],
                            memory_in_gbs=cfg["memory"]
                        ),
                        source_details=oci.core.models.InstanceSourceViaImageDetails(
                            image_id=image_id
                        ),
                        create_vnic_details=oci.core.models.CreateVnicDetails(
                            subnet_id=subnet_id,
                            assign_public_ip=True
                        )
                    )

                    try:
                        result = data = compute_client.launch_instance(request)
                        elapsed = int(time.time() - start_time)
                        success_msg = (
                            f"KAPTAN MUJDE!!!\n\n"
                            f"Oracle Avci Botumuz sunucu YAKALADI!\n"
                            f"Config: {cfg['name']}\n"
                            f"AD: {short_ad}\n"
                            f"Deneme: #{attempts} ({elapsed}sn)\n\n"
                            f"Hemen Oracle paneline gir!"
                        )
                        print(f"\n{'!'*60}")
                        print(f"  [SUCCESS] BINGO!!! {cfg['name']} YAKALANDI!")
                        print(f"  AD: {short_ad} | Deneme #{attempts}")
                        print(f"{'!'*60}\n")
                        send_telegram_alert(success_msg)
                        return

                    except oci.exceptions.ServiceError as e:
                        msg = e.message.lower() if e.message else ""
                        if e.status == 500 or "capacity" in msg or "host" in msg:
                            pass  # Stok yok, devam
                        elif e.status == 429:
                            print(f"[{datetime.now().strftime('%H:%M:%S')}] #{attempts} | 429 Limit! 30sn bekleme...")
                            time.sleep(30)
                        elif "limit" in msg:
                            pass  # Free tier limit
                        else:
                            pass  # Diger hatalar

            # Her tur sonunda tek satirlik ozet
            elapsed_min = int((time.time() - start_time) / 60)
            ts = datetime.now().strftime('%H:%M:%S')
            print(f"[{ts}] Tur bitimi | #{attempts} deneme | {elapsed_min}dk | Stok yok. 6sn bekleniyor (Ban-Korumali Hız)...")
            time.sleep(6)

    except Exception as e:
        print(f"[FATAL] Beklenmeyen Hata: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    hunt_for_server()
