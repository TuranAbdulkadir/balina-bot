from decimal import Decimal

class FeeMath:
    """
    VIP0 Binance Futures Fee Mathematics & Arbitrage Guard.
    """
    MAKER_FEE_RATE = Decimal("0.0002")  # 0.02%
    TAKER_FEE_RATE = Decimal("0.0005")  # 0.05%

    @staticmethod
    def calculate_breakeven_ask(entry_buy_price: Decimal, fee_rate: Decimal = MAKER_FEE_RATE) -> Decimal:
        """
        Calculates the absolute minimum ASK required to sell purely rounding up 
        to escape the entry + exit fee drag.
        1 BTC bought at 65000 -> 13$ fee. Sold at 65000 -> 13$ fee. Spread must exceed 26$.
        """
        # (entry / (1 - sell_fee)) + entry * buy_fee --> robust formula
        # S - S*f_s - B*f_b - B > 0 => S > B * (1 + f_b) / (1 - f_s)
        target = entry_buy_price * (Decimal("1.0") + fee_rate) / (Decimal("1.0") - fee_rate)
        return target

    @staticmethod
    def calculate_breakeven_bid(entry_sell_price: Decimal, fee_rate: Decimal = MAKER_FEE_RATE) -> Decimal:
        """
        Calculates the absolute minimum BID required to buy to cover a Short squeeze entry.
        B + B*f_b + S*f_s - S < 0 => B < S * (1 - f_s) / (1 + f_b)
        """
        target = entry_sell_price * (Decimal("1.0") - fee_rate) / (Decimal("1.0") + fee_rate)
        return target

    @staticmethod
    def is_spread_profitable(bid: float, ask: float, fee_rate: Decimal = MAKER_FEE_RATE) -> bool:
        """
        Determines if the active LOB tight spread inherently covers double maker fees.
        """
        b_dec = Decimal(str(bid))
        a_dec = Decimal(str(ask))
        if b_dec == 0: return False
        
        profit_margin = (a_dec - b_dec) / b_dec
        return profit_margin > (fee_rate * 2)

    @staticmethod
    def calc_real_vpin(aggtrade_buffer, bucket_size: int = 1000) -> float:
        """
        Calculate real VPIN from aggTrade data.
        buy_volume = trades where is_market_maker == False
        sell_volume = trades where is_market_maker == True  
        VPIN = |buy_vol - sell_vol| / total_vol
        """
        if not aggtrade_buffer:
            return 0.0
            
        buy_vol = sum(t['qty'] for t in aggtrade_buffer if not t['is_market_maker'])
        sell_vol = sum(t['qty'] for t in aggtrade_buffer if t['is_market_maker'])
        total_vol = buy_vol + sell_vol
        
        if total_vol == 0:
            return 0.0
            
        vpin = abs(buy_vol - sell_vol) / total_vol
        
        # Sadece loglama (stratejide kullanilmiyor)
        from core.logger_factory import get_logger
        logger = get_logger("RealVPIN")
        logger.info(f"REAL_VPIN={vpin:.4f} (monitoring)")
        
        return vpin
