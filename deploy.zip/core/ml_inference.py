"""
OTOMATIK URETILMIS AI CIKARIM MOTORU
İlk kurulum varsayılanıdır. /ml komutu ile XGBoost modeli egitildiginde bu dosya gercek agaclarla guncellenecektir.
"""
def predict_hit(zscore: float, vpin: float, obi: float) -> float:
    # Eger model henuz egitilmemisse her isleme %100 onay verir (Fallback)
    return 1.0

def is_model_ready() -> bool:
    return False
