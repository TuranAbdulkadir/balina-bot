import asyncio
import aiohttp
import time
from core.logger_factory import get_logger

logger = get_logger("TrendFilter")

class TrendFilter:
    def __init__(self, symbol: str = "BTCUSDT", interval: str = "15m", limit: int = 50):
        self.symbol = symbol
        self.interval = interval
        self.limit = limit
        self.trend = "NEUTRAL"
        self.last_update = 0
        # REST endpoint for klines (No Auth required)
        self.url = "https://fapi.binance.com/fapi/v1/klines"

    async def update_loop(self):
        logger.info(f"TrendFilter initiated for {self.symbol} ({self.interval})")
        async with aiohttp.ClientSession() as session:
            while True:
                try:
                    params = {
                        "symbol": self.symbol,
                        "interval": self.interval,
                        "limit": self.limit
                    }
                    async with session.get(self.url, params=params, timeout=5.0) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            self._calculate_trend(data)
                        else:
                            logger.warning(f"Failed to fetch klines: HTTP {resp.status}")
                            self.trend = "NEUTRAL"
                except Exception as e:
                    logger.error(f"Trend filter error: {e}")
                    self.trend = "NEUTRAL"
                
                await asyncio.sleep(60)

    def _calculate_trend(self, klines: list):
        if not klines or len(klines) < 21:
            self.trend = "NEUTRAL"
            return
            
        closes = [float(k[4]) for k in klines]
        highs = [float(k[2]) for k in klines]
        lows = [float(k[3]) for k in klines]
        volumes = [float(k[5]) for k in klines]
        
        current_close = closes[-1]
        
        # Calculate EMA-21
        ema21 = self._calculate_ema(closes, 21)
        
        # Calculate VWAP
        typical_prices = [(highs[i] + lows[i] + closes[i]) / 3.0 for i in range(len(klines))]
        total_volume = sum(volumes)
        if total_volume > 0:
            vwap = sum(tp * vol for tp, vol in zip(typical_prices, volumes)) / total_volume
        else:
            vwap = current_close
        
        if current_close > ema21 and current_close > vwap:
            new_trend = "BULL"
        elif current_close < ema21 and current_close < vwap:
            new_trend = "BEAR"
        else:
            new_trend = "NEUTRAL"
            
        if self.trend != new_trend:
            logger.info(f"[{self.symbol}] Makro Trend Degisti: {self.trend} -> {new_trend} (Fiyat: {current_close:.2f}, EMA: {ema21:.2f}, VWAP: {vwap:.2f})")
            
        self.trend = new_trend
        self.last_update = time.time()

    def _calculate_ema(self, prices: list, period: int) -> float:
        if len(prices) < period:
            return prices[-1]
            
        multiplier = 2 / (period + 1)
        ema = sum(prices[:period]) / period
        
        for price in prices[period:]:
            ema = (price - ema) * multiplier + ema
            
        return ema
        
    def get_trend(self) -> str:
        return self.trend
