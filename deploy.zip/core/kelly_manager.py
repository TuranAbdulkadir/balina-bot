from decimal import Decimal, ROUND_DOWN
from core.logger_factory import get_logger

logger = get_logger("KellyManager")

from collections import deque

class KellyRiskManager:
    """
    Implements Fractional Kelly Criterion for Autonomous Portfolio Compounding.
    Replaces static trade sizes with dynamically bound Volatility-adjusted allocations.
    """
    def __init__(self, kelly_fraction: str = "0.20", max_leverage: str = "10.0", history_size: int = 200, reporter=None):
        self.kelly_fraction = Decimal(kelly_fraction)  # E.g. Fractional Kelly (20% of Full Kelly)
        self.max_leverage = Decimal(max_leverage)
        self.reporter = reporter # AŞAMA 19: Simülasyon köprüsü
        self.trade_history = deque(maxlen=history_size)
        
    def record_trade_result(self, pnl_usd: float):
        """Records a closed trade's PnL to adjust future probability parameters."""
        self.trade_history.append(float(pnl_usd))
        
    def calculate_trade_size(self, current_balance_usdt: Decimal, current_price: float, volatility_ratio: float = 1.0) -> Decimal:
        """
        Kelly % = W - [(1 - W) / R]
        Where W = Historical Win Rate, R = Reward/Risk Ratio
        Automatically dynamically adjusts R based on realized historical returns.
        """
        try:
            if current_balance_usdt <= Decimal("0"):
                return Decimal("0")
                
            if self.reporter:
                pnl_list = self.reporter.pnl_history
            else:
                pnl_list = list(self.trade_history)

            total_trades = len(pnl_list)
            
            # Yeterli istatistiksel veri yoksa (20 islem), Kelly hesaplanamaz.
            if total_trades < 20:
                usd_allocation = Decimal("15.0") # Sabit min. lot (15 USDT)
                price_dec = Decimal(str(current_price))
                coin_quantity = usd_allocation / price_dec
                return coin_quantity.quantize(Decimal("0.001"), rounding=ROUND_DOWN)
            
            # Dynamic Win Rate (Son 50 Islem Rolling)
            recent_pnls = pnl_list[-50:]
            wins = sum(1 for p in recent_pnls if p > 0)
            organic_win_rate = (wins / len(recent_pnls))
            
            # Dynamic Win/Loss Ratio Calibration (Kumulatif)
            wins_pnl = [p for p in pnl_list if p > 0]
            loss_pnl = [abs(p) for p in pnl_list if p < 0]
            avg_win = sum(wins_pnl) / len(wins_pnl) if wins_pnl else 1.0
            avg_loss = sum(loss_pnl) / len(loss_pnl) if loss_pnl else 1.0
            dynamic_win_loss_ratio = max(0.5, min(3.0, avg_win / avg_loss))
                
            w = Decimal(str(organic_win_rate))
            r = Decimal(str(dynamic_win_loss_ratio))
            
            # Full Kelly
            kelly_pct = w - ((Decimal("1.0") - w) / r)
            
            if kelly_pct <= Decimal("0"):
                return Decimal("0") # Strategy edge evaporated
                
            # Fractional Kelly for safety
            fraction = self.kelly_fraction
            if volatility_ratio > 2.0:
                fraction = fraction / Decimal("2.0")
                logger.warning(f"⚠️ AŞIRI VOLATİLİTE (x{volatility_ratio:.1f}): Kelly Risk Oranı Yarıya İndirildi! (%{float(fraction)*100})")
                
            safe_allocation_pct = kelly_pct * fraction
            
            # Hardcap against margin limits (e.g., 5.0 means 5x your wallet size)
            if safe_allocation_pct > self.max_leverage:
                safe_allocation_pct = self.max_leverage
                
            usd_allocation = current_balance_usdt * safe_allocation_pct
            price_dec = Decimal(str(current_price))
            
            coin_quantity = usd_allocation / price_dec
            return coin_quantity.quantize(Decimal("0.001"), rounding=ROUND_DOWN)
            
        except Exception as e:
            logger.error(f"Kelly sizing failed: {e}")
            return Decimal("0")
