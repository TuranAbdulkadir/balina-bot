import os
import glob
import json
import time
import sys
import re
import pandas as pd
import numpy as np
from datetime import datetime
from core.logger_factory import get_logger

logger = get_logger("MLOptimizer")

try:
    import xgboost as xgb
    from sklearn.model_selection import TimeSeriesSplit
    from sklearn.metrics import accuracy_score, precision_score
except ImportError:
    print("🚨 XGBoost veya scikit-learn kutuphanesi bulunamadi!")
    print("Lutfen terminalde su komutu calistirin: pip install xgboost scikit-learn pandas pyarrow numpy")
    sys.exit(1)

DATA_DIR = "core/data_lake"
CONFIG_FILE = "core/ml_config.json"
INFERENCE_FILE = "core/ml_inference.py"

def load_data():
    files = glob.glob(os.path.join(DATA_DIR, "*.parquet"))
    if not files:
        logger.warning("Parquet dosyasi bulunamadi. Data Lake bos.")
        return None
        
    dfs = []
    for f in files:
        try:
            df = pd.read_parquet(f)
            dfs.append(df)
        except Exception as e:
            logger.error(f"Dosya okuma hatasi {f}: {e}")
            
    if not dfs: return None
    
    full_df = pd.concat(dfs, ignore_index=True)
    full_df.sort_values("timestamp", inplace=True)
    full_df.reset_index(drop=True, inplace=True)
    return full_df

def parse_xgb_tree(dump_text):
    """XGBoost agacini Python koduna cevirir."""
    lines = dump_text.strip().split('\n')
    nodes = {}
    for line in lines:
        line = line.strip()
        if not line: continue
        parts = line.split(':')
        node_id = int(parts[0])
        content = ':'.join(parts[1:])
        if content.startswith('leaf='):
            val = float(content.replace('leaf=', ''))
            nodes[node_id] = {'type': 'leaf', 'val': val}
        else:
            m = re.match(r'\[(.*)<(.*)\]\s+yes=(.*),no=(.*),missing=(.*)', content)
            if m:
                nodes[node_id] = {
                    'type': 'split', 
                    'feat': m.group(1), 
                    'thresh': float(m.group(2)), 
                    'yes': int(m.group(3)), 
                    'no': int(m.group(4))
                }

    def build_code(node_id, indent):
        node = nodes[node_id]
        spaces = " " * indent
        if node['type'] == 'leaf':
            return f"{spaces}score += {node['val']}\n"
        else:
            code = f"{spaces}if {node['feat']} < {node['thresh']}:\n"
            code += build_code(node['yes'], indent + 4)
            code += f"{spaces}else:\n"
            code += build_code(node['no'], indent + 4)
            return code

    return build_code(0, 4)

def export_model_to_python(booster, output_path):
    """Sifir-gecikme (Zero-Latency) Hardcoded Inference ureteci."""
    trees = booster.get_dump()
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\"\"\"\nOTOMATIK URETILMIS AI CIKARIM MOTORU\nXGBoost modellerinden transpile edilmistir.\n\"\"\"\n")
        f.write("import math\n\n")
        
        # Base score in XGBoost binary classification is usually 0.0 before sigmoid.
        # However, XGBoost uses base_score=0.5 -> log(0.5/(1-0.5)) = 0.0
        f.write("def predict_hit(zscore: float, vpin: float, obi: float) -> float:\n")
        f.write("    score = 0.0\n")
        
        for i, tree in enumerate(trees):
            f.write(f"\n    # Tree {i}\n")
            f.write(parse_xgb_tree(tree))
            
        f.write("\n    # Sigmoid function for probability\n")
        f.write("    try:\n")
        f.write("        prob = 1.0 / (1.0 + math.exp(-score))\n")
        f.write("    except OverflowError:\n")
        f.write("        prob = 0.0 if score < 0 else 1.0\n")
        f.write("    return prob\n")
        f.write("\n# Default fallback for safety\n")
        f.write("def is_model_ready(): return True\n")
        
    logger.info(f"Yapay Zeka kodlari Python IF/ELSE bloklarina donusturuldu -> {output_path}")

def run_optimization():
    logger.info("Data Lake uzerinden veriler yukleniyor (Zero-Latency ML Optimizasyonu)...")
    df = load_data()
    if df is None or len(df) < 500:
        logger.warning(f"Yetersiz veri! En az 500 tick gerekiyor. (Bulunan: {len(df) if df is not None else 0})")
        sys.exit(0)
        
    logger.info(f"Toplam {len(df):,} tick verisi isleniyor.")
    
    # 10 tick sonrasindaki fiyat yonunu hesapla
    df['mid_price'] = (df['best_bid'] + df['best_ask']) / 2.0
    df['future_price_10'] = df['mid_price'].shift(-10)
    df.dropna(subset=['future_price_10'], inplace=True)
    
    conditions = [
        (df['zscore'] > 0) & (df['future_price_10'] < df['mid_price']),
        (df['zscore'] < 0) & (df['future_price_10'] > df['mid_price'])
    ]
    df['hit'] = np.select(conditions, [1, 1], default=0)
    
    features = ['zscore', 'vpin', 'obi']
    
    # ML sadece ciddi aksiyon bolgelerine egitilmelidir. Yatay veri parazittir.
    anomaly_df = df[df['zscore'].abs() > 3.0].copy()
    if len(anomaly_df) < 100:
        logger.warning("Egitim icin yeterli anomali verisi (Z-Score > 3.0) yok.")
        sys.exit(0)
        
    X = anomaly_df[features]
    y = anomaly_df['hit']
    
    logger.info("Time-Series Split (Gelecekten Gecmise Siziinti Korumasi) Devrede.")
    tscv = TimeSeriesSplit(n_splits=3)
    
    # 10 Tree, Max Depth 4 (Cok hizli ve kucuk Python kodu uretebilmek icin mikromodel)
    model = xgb.XGBClassifier(
        n_estimators=10, 
        max_depth=4, 
        use_label_encoder=False, 
        eval_metric='logloss',
        learning_rate=0.1
    )
    
    for train_index, test_index in tscv.split(X):
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]
        y_train, y_test = y.iloc[train_index], y.iloc[test_index]
        model.fit(X_train, y_train)
    
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    logger.info(f"Final Fold - Accuracy: %{acc * 100:.2f} | Precision: %{prec * 100:.2f}")
    
    # Modeli pure Python mantigina derle
    export_model_to_python(model.get_booster(), INFERENCE_FILE)
    
    config = {
        "model_accuracy": round(float(acc), 4),
        "model_precision": round(float(prec), 4),
        "last_updated": datetime.utcnow().isoformat(),
        "total_ticks_analyzed": len(df)
    }
    
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)
        
    logger.info(f"Model Konfigurasyonu '{CONFIG_FILE}' dosyasina mühürlendi.")

if __name__ == "__main__":
    run_optimization()
