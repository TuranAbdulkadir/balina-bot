"""
=============================================================================
BALINA-BOT BACKTEST ENGINE v1.0
=============================================================================
Gerçek tick verisi (core/data_lake/*.parquet) üzerinde çalışan,
mevcut canlı stratejiyle (Z-Score + VPIN + OBI + EMA-OBI) tam uyumlu
profesyonel backtest motoru.

Özellikler:
  - Polars ile yüksek performanslı veri okuma (470 x 50k satır)
  - LOB VWAP slippage modellemesi
  - Maker/Taker fee muhasebesi
  - Walk-forward validation (%70 train / %30 test)
  - Z-Score ve VPIN eşiği sensitivity analizi
  - Sharpe, Drawdown, Win Rate, Avg Trade Duration
  - Parquet + HTML rapor çıktısı (backtest_results/)
=============================================================================
"""

import os
import sys
import time
import math
import glob
import json
import logging
import argparse
from dataclasses import dataclass, field, asdict
from collections import deque
from typing import List, Optional, Dict, Tuple

import polars as pl
import pyarrow as pa
import pyarrow.parquet as pq

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("BacktestEngine")

# ─── SABITLER ────────────────────────────────────────────────────────────────
DATA_DIR        = "core/data_lake"
RESULTS_DIR     = "backtest_results"
MAKER_FEE       = 0.0002   # 0.02%
TAKER_FEE       = 0.0004   # 0.04%
INITIAL_CAPITAL = 10_000.0 # USDT
ZSCORE_WINDOW   = 3_000    # rolling Z-Score hesaplama penceresi
EMA_FAST_ALPHA  = 0.05     # ~20 tick EMA
EMA_SLOW_ALPHA  = 0.005    # ~200 tick EMA
OBI_EMA_ALPHA   = 0.1      # OBI EMA
VPIN_WINDOW     = 50       # VPIN hesaplama bucket büyüklüğü
MAX_POSITION_FRACTION = 0.10   # Cüzdan bakiyesinin max %10'u
TRAIN_RATIO     = 0.70     # Walk-forward train oranı
MIN_TICKS_REQUIRED = 5_000  # Sinyal üretimi için minimum tick sayısı

# ─── VERİ YAPILARI ──────────────────────────────────────────────────────────

@dataclass
class Trade:
    entry_tick: int
    exit_tick: int
    side: str          # "BUY" veya "SELL"
    entry_price: float
    exit_price: float
    quantity: float
    fee_total: float
    pnl_gross: float
    pnl_net: float
    exit_reason: str
    entry_zscore: float
    entry_vpin: float
    entry_obi: float

@dataclass
class BacktestResult:
    symbol: str
    param_tag: str
    total_pnl_usdt: float = 0.0
    total_pnl_pct: float = 0.0
    sharpe_ratio: float = 0.0
    max_drawdown_pct: float = 0.0
    win_rate_pct: float = 0.0
    total_trades: int = 0
    winning_trades: int = 0
    avg_trade_ticks: float = 0.0
    final_balance: float = INITIAL_CAPITAL
    trades: List[Trade] = field(default_factory=list)

# ─── İNDİKATÖR HESAPLAYICI ───────────────────────────────────────────────────

class IndicatorEngine:
    """
    Canlı strateji ile birebir aynı indikatör hesaplama motoru.
    Vektörel değil — tick-by-tick (gerçek canlı ortam simülasyonu).
    """

    def __init__(self):
        self._price_window: deque = deque(maxlen=ZSCORE_WINDOW)
        self._price_sum = 0.0
        self._price_sq_sum = 0.0
        self._ema_mid: float = 0.0
        self._ema_obi: float = 0.0
        self._short_vol: float = 0.0   # ~20 tick hızlı volatilite
        self._long_vol: float = 0.0    # ~200 tick yavaş volatilite
        self._vpin_buys: deque = deque(maxlen=VPIN_WINDOW)
        self._vpin_sells: deque = deque(maxlen=VPIN_WINDOW)
        self._vpin_buys_sum = 0.0
        self._vpin_sells_sum = 0.0
        self._tick_count: int = 0
        self.initialized: bool = False

    def update(self, bid: float, ask: float, bid_qty: float, ask_qty: float,
               trade_qty: float = 0.0, is_buyer_maker: Optional[bool] = None
               ) -> Dict[str, float]:
        """
        Her tick için indikatörleri günceller ve döndürür.
        Returns: {'zscore', 'vpin', 'obi', 'ema_obi', 'short_vol', 'long_vol', 'mid'}
        """
        if bid <= 0.0 or ask <= 0.0:
            return {}

        mid = (bid + ask) / 2.0
        self._tick_count += 1

        # ── Fiyat geçmişi ve Z-Score (O(1) Rolling Var) ──
        if len(self._price_window) == ZSCORE_WINDOW:
            popped = self._price_window[0]
            self._price_sum -= popped
            self._price_sq_sum -= popped * popped
            
        self._price_window.append(mid)
        self._price_sum += mid
        self._price_sq_sum += mid * mid

        if len(self._price_window) < 30:
            return {}  # Yeterli veri yok

        n = len(self._price_window)
        mean_p = self._price_sum / n
        variance = (self._price_sq_sum - n * mean_p * mean_p) / n
        if variance < 0: variance = 0
        std_p = math.sqrt(variance) if variance > 0 else 1e-9
        zscore = (mid - mean_p) / std_p

        # ── Volatilite (EMA-bazlı absolüt getiri) ──
        if self._ema_mid == 0.0:
            self._ema_mid = mid
        abs_ret = abs(mid - self._ema_mid)
        self._ema_mid = EMA_FAST_ALPHA * mid + (1 - EMA_FAST_ALPHA) * self._ema_mid
        self._short_vol = EMA_FAST_ALPHA * abs_ret + (1 - EMA_FAST_ALPHA) * self._short_vol
        self._long_vol = EMA_SLOW_ALPHA * abs_ret + (1 - EMA_SLOW_ALPHA) * self._long_vol

        # ── OBI (Order Book Imbalance) ──
        total_qty = bid_qty + ask_qty
        obi = (bid_qty - ask_qty) / total_qty if total_qty > 0 else 0.0
        self._ema_obi = OBI_EMA_ALPHA * obi + (1 - OBI_EMA_ALPHA) * self._ema_obi

        # ── VPIN (Volume-Sync'd Probability of Informed Trading) ──
        # aggTrade var ise kullan, yoksa quote imbalance proxy
        if is_buyer_maker is not None and trade_qty > 0:
            sell_vol = trade_qty if is_buyer_maker else 0.0
            buy_vol = 0.0 if is_buyer_maker else trade_qty
        else:
            # bookTicker proxy: bid hacmi alıcı, ask hacmi satıcı
            buy_vol = bid_qty
            sell_vol = ask_qty

        if len(self._vpin_buys) == VPIN_WINDOW:
            self._vpin_buys_sum -= self._vpin_buys[0]
            self._vpin_sells_sum -= self._vpin_sells[0]
            
        self._vpin_buys.append(buy_vol)
        self._vpin_sells.append(sell_vol)
        self._vpin_buys_sum += buy_vol
        self._vpin_sells_sum += sell_vol

        total_bucket = self._vpin_buys_sum + self._vpin_sells_sum
        vpin = abs(self._vpin_buys_sum - self._vpin_sells_sum) / total_bucket \
               if total_bucket > 0 else 0.0

        self.initialized = (len(self._price_window) >= ZSCORE_WINDOW)

        return {
            "zscore": zscore,
            "vpin": vpin,
            "obi": obi,
            "ema_obi": self._ema_obi,
            "short_vol": self._short_vol,
            "long_vol": self._long_vol,
            "mid": mid,
        }

    def get_volatility_ratio(self) -> float:
        return self._short_vol / self._long_vol if self._long_vol > 0 else 1.0

# ─── SLIPPAGE MODELİ ─────────────────────────────────────────────────────────

def simulate_fill_price(side: str, quantity: float, bid: float, ask: float,
                        bid_qty: float, ask_qty: float) -> Tuple[float, bool]:
    """
    LOB VWAP slippage modellemesi — mevcut smart_slice_exit mantığıyla aynı.
    Returns: (fill_price, is_maker)
    Maker (GTX post-only) doluysa bid/ask, aksi halde VWAP slippage uygulanır.
    """
    if side == "BUY":
        best_price = ask
        visible_liq = ask_qty
    else:
        best_price = bid
        visible_liq = bid_qty

    if quantity <= visible_liq * 0.15:
        # Likidite yeterli — Maker fill (post-only)
        return best_price, True
    else:
        # Slippage: miktarın visible_liq'e oranına göre penalty
        overshoot = (quantity - visible_liq * 0.15) / visible_liq
        penalty = min(overshoot * 0.001, 0.005)  # max 0.5% slippage
        if side == "BUY":
            return best_price * (1 + penalty), False
        else:
            return best_price * (1 - penalty), False

# ─── POZİSYON YÖNETİCİSİ ────────────────────────────────────────────────────

@dataclass
class Position:
    side: str
    entry_price: float
    quantity: float
    entry_tick: int
    entry_zscore: float
    entry_vpin: float
    entry_obi: float
    is_open: bool = True

    def breakeven_ask(self) -> float:
        """Karda çıkmak için minimum ask fiyatı."""
        return self.entry_price * (1 + MAKER_FEE) / (1 - MAKER_FEE)

    def breakeven_bid(self) -> float:
        """Short için karda çıkmak için maksimum bid fiyatı."""
        return self.entry_price * (1 - MAKER_FEE) / (1 + MAKER_FEE)

    def stop_loss_price(self, kelly_fraction: float = 0.05) -> float:
        """Kelly fraksiyonuna göre stop-loss seviyesi."""
        if self.side == "BUY":
            return self.entry_price * (1 - kelly_fraction)
        else:
            return self.entry_price * (1 + kelly_fraction)

# ─── ANA BACKTEST MOTORU ─────────────────────────────────────────────────────

class BacktestEngine:
    def __init__(
        self,
        symbol: str = "BTCUSDT",
        z_threshold: float = 4.5,
        vpin_threshold: float = 0.65,
        initial_capital: float = INITIAL_CAPITAL,
        kelly_fraction: float = 0.05,
    ):
        self.symbol = symbol
        self.z_threshold = z_threshold
        self.vpin_threshold = vpin_threshold
        self.capital = initial_capital
        self.initial_capital = initial_capital
        self.kelly_fraction = kelly_fraction

        self.indicator = IndicatorEngine()
        self.position: Optional[Position] = None
        self.trades: List[Trade] = []
        self.equity_curve: List[float] = [initial_capital]

        self._tick_idx: int = 0
        self._cooldown_ticks: int = 0

    def _can_enter(self, signals: dict, trend_ok: bool = True) -> Optional[str]:
        """Giriş koşullarını kontrol eder. 'BUY'/'SELL'/None döndürür."""
        if self.position is not None:
            return None
        if self._cooldown_ticks > 0:
            return None
        if not self.indicator.initialized:
            return None

        z = signals["zscore"]
        vpin = signals["vpin"]
        obi = signals["obi"]

        # Volatilite kalkanı: aşırı oynaklıkta giriş yapma
        vol_ratio = self.indicator.get_volatility_ratio()
        effective_z = self.z_threshold * max(1.0, min(2.0, vol_ratio))

        if vpin > self.vpin_threshold:
            return None

        if z > effective_z and obi > 0.05 and trend_ok:
            return "BUY"
        elif z < -effective_z and obi < -0.05 and trend_ok:
            return "SELL"

        return None

    def _enter_position(self, side: str, tick_idx: int, signals: dict,
                        bid: float, ask: float, bid_qty: float, ask_qty: float):
        """Pozisyon açar."""
        qty = (self.capital * MAX_POSITION_FRACTION * self.kelly_fraction) / (
            ask if side == "BUY" else bid
        )
        qty = max(qty, 1e-6)

        fill_price, is_maker = simulate_fill_price(
            side, qty, bid, ask, bid_qty, ask_qty
        )
        fee_rate = MAKER_FEE if is_maker else TAKER_FEE
        fee = fill_price * qty * fee_rate

        self.capital -= fee
        self.position = Position(
            side=side,
            entry_price=fill_price,
            quantity=qty,
            entry_tick=tick_idx,
            entry_zscore=signals["zscore"],
            entry_vpin=signals["vpin"],
            entry_obi=signals["obi"],
        )

    def _exit_position(self, tick_idx: int, signals: dict, bid: float, ask: float,
                       bid_qty: float, ask_qty: float, reason: str):
        """Açık pozisyonu kapatır ve trade kaydeder."""
        if self.position is None:
            return

        pos = self.position
        exit_side = "SELL" if pos.side == "BUY" else "BUY"

        fill_price, is_maker = simulate_fill_price(
            exit_side, pos.quantity, bid, ask, bid_qty, ask_qty
        )
        fee_rate = MAKER_FEE if is_maker else TAKER_FEE
        exit_fee = fill_price * pos.quantity * fee_rate
        entry_fee = pos.entry_price * pos.quantity * MAKER_FEE

        if pos.side == "BUY":
            pnl_gross = (fill_price - pos.entry_price) * pos.quantity
        else:
            pnl_gross = (pos.entry_price - fill_price) * pos.quantity

        fee_total = entry_fee + exit_fee
        pnl_net = pnl_gross - fee_total

        self.capital += pnl_net
        self.equity_curve.append(self.capital)

        trade = Trade(
            entry_tick=pos.entry_tick,
            exit_tick=tick_idx,
            side=pos.side,
            entry_price=pos.entry_price,
            exit_price=fill_price,
            quantity=pos.quantity,
            fee_total=fee_total,
            pnl_gross=pnl_gross,
            pnl_net=pnl_net,
            exit_reason=reason,
            entry_zscore=pos.entry_zscore,
            entry_vpin=pos.entry_vpin,
            entry_obi=pos.entry_obi,
        )
        self.trades.append(trade)
        self.position = None
        self._cooldown_ticks = 30  # 30 tick soğuma

    def _check_exit(self, tick_idx: int, signals: dict,
                    bid: float, ask: float, bid_qty: float, ask_qty: float) -> bool:
        """Çıkış koşullarını kontrol eder."""
        if self.position is None:
            return False

        pos = self.position
        z = signals["zscore"]
        obi_delta = signals["obi"] - signals["ema_obi"]
        vpin = signals["vpin"]

        # ── Stop-Loss ──
        sl_price = pos.stop_loss_price(self.kelly_fraction)
        mid = signals["mid"]

        if pos.side == "BUY" and mid < sl_price:
            self._exit_position(tick_idx, signals, bid, ask, bid_qty, ask_qty, "STOP_LOSS")
            return True
        if pos.side == "SELL" and mid > sl_price:
            self._exit_position(tick_idx, signals, bid, ask, bid_qty, ask_qty, "STOP_LOSS")
            return True

        # ── Toksik akış ──
        if vpin > 0.85:
            self._exit_position(tick_idx, signals, bid, ask, bid_qty, ask_qty, "TOXIC_FLOW")
            return True

        # ── Kâr Kilidi (early profit lock): breakeven + momentum dönüşü ──
        if pos.side == "BUY":
            breakeven = pos.breakeven_ask()
            if ask >= breakeven and (z < 0.0 or obi_delta < -0.1):
                self._exit_position(tick_idx, signals, bid, ask, bid_qty, ask_qty, "PROFIT_LOCK")
                return True
        else:
            breakeven = pos.breakeven_bid()
            if bid <= breakeven and (z > 0.0 or obi_delta > 0.1):
                self._exit_position(tick_idx, signals, bid, ask, bid_qty, ask_qty, "PROFIT_LOCK")
                return True

        # ── Z-Score geri döndü (sinyal bitti) ──
        if pos.side == "BUY" and z < -1.5:
            self._exit_position(tick_idx, signals, bid, ask, bid_qty, ask_qty, "SIGNAL_REVERSAL")
            return True
        if pos.side == "SELL" and z > 1.5:
            self._exit_position(tick_idx, signals, bid, ask, bid_qty, ask_qty, "SIGNAL_REVERSAL")
            return True

        # ── Maksimum pozisyon ömrü: 2000 tick ──
        if tick_idx - pos.entry_tick > 2000:
            self._exit_position(tick_idx, signals, bid, ask, bid_qty, ask_qty, "TTL_EXPIRED")
            return True

        return False

    def run(self, ticks: pl.DataFrame) -> BacktestResult:
        """Ana backtest döngüsü."""
        # Sadece bookTicker satırlarını kullan (bid/ask içeren)
        bticker = ticks.filter(pl.col("type") == "bookTicker")

        total_rows = len(bticker)
        logger.info(f"  Symbol={self.symbol} | Ticks={total_rows:,} | Z={self.z_threshold} | VPIN={self.vpin_threshold}")

        bid_arr = bticker["bid_price"].to_list()
        ask_arr = bticker["ask_price"].to_list()
        bq_arr  = bticker["bid_qty"].to_list()
        aq_arr  = bticker["ask_qty"].to_list()

        self._cooldown_ticks = 0

        for i in range(total_rows):
            bid = bid_arr[i]
            ask = ask_arr[i]
            bid_qty = bq_arr[i]
            ask_qty = aq_arr[i]

            if bid is None or ask is None or bid <= 0 or ask <= 0:
                continue

            signals = self.indicator.update(bid, ask, bid_qty or 0, ask_qty or 0)
            if not signals:
                continue

            self._tick_idx = i

            if self._cooldown_ticks > 0:
                self._cooldown_ticks -= 1

            # Çıkış kontrolü her zaman önce
            if self.position is not None:
                self._check_exit(i, signals, bid, ask, bid_qty or 0, ask_qty or 0)

            # Giriş kontrolü
            if self.position is None:
                direction = self._can_enter(signals)
                if direction:
                    self._enter_position(direction, i, signals, bid, ask,
                                         bid_qty or 0, ask_qty or 0)

        # Dönem sonunda açık pozisyon varsa kapat
        if self.position is not None and len(bid_arr) > 0:
            dummy_signals = {"zscore": 0, "vpin": 0, "obi": 0, "ema_obi": 0, "mid": bid_arr[-1]}
            self._exit_position(total_rows - 1, dummy_signals,
                                bid_arr[-1], ask_arr[-1],
                                bq_arr[-1] or 1.0, aq_arr[-1] or 1.0,
                                "PERIOD_END")

        return self._compute_result()

    def _compute_result(self) -> BacktestResult:
        """Metrik hesaplamalarını yapar."""
        tag = f"Z{self.z_threshold}_VP{self.vpin_threshold}"
        result = BacktestResult(symbol=self.symbol, param_tag=tag)

        if not self.trades:
            result.final_balance = self.capital
            return result

        pnls = [t.pnl_net for t in self.trades]
        wins = [p for p in pnls if p > 0]
        total_pnl = sum(pnls)

        result.total_pnl_usdt = total_pnl
        result.total_pnl_pct = (total_pnl / self.initial_capital) * 100
        result.total_trades = len(self.trades)
        result.winning_trades = len(wins)
        result.win_rate_pct = (len(wins) / len(self.trades)) * 100
        result.avg_trade_ticks = sum(
            t.exit_tick - t.entry_tick for t in self.trades
        ) / len(self.trades)
        result.final_balance = self.capital
        result.trades = self.trades

        # ── Sharpe Ratio (annualized) ──
        if len(pnls) > 1:
            mean_pnl = total_pnl / len(pnls)
            variance = sum((p - mean_pnl) ** 2 for p in pnls) / len(pnls)
            std_pnl = math.sqrt(variance) if variance > 0 else 1e-9
            sharpe_raw = mean_pnl / std_pnl
            # Annualize: yaklaşık günlük trade sayısı * 365
            trades_per_day = max(1, len(self.trades))  # basit annualize
            result.sharpe_ratio = sharpe_raw * math.sqrt(trades_per_day)
        else:
            result.sharpe_ratio = 0.0

        # ── Max Drawdown ──
        equity = self.equity_curve
        peak = equity[0]
        max_dd = 0.0
        for e in equity:
            if e > peak:
                peak = e
            dd = (peak - e) / peak if peak > 0 else 0.0
            if dd > max_dd:
                max_dd = dd
        result.max_drawdown_pct = max_dd * 100

        return result

# ─── VERİ YÜKLEYICI ──────────────────────────────────────────────────────────

def load_data(symbol: str = "BTCUSDT", max_files: Optional[int] = None) -> pl.DataFrame:
    """
    core/data_lake/ içindeki Parquet dosyalarını filtreler ve zaman sırasına göre okur.
    Polars LazyFrame ile bellek verimli yükleme.
    """
    pattern = os.path.join(DATA_DIR, "multipair_ticks_*.parquet")
    files = sorted(glob.glob(pattern))

    if not files:
        raise FileNotFoundError(f"Parquet dosyası bulunamadı: {pattern}")

    if max_files:
        files = files[:max_files]

    logger.info(f"Toplam {len(files)} Parquet dosyası yükleniyor ({symbol})...")

    # Polars lazy okuma — sadece gerekli sütunlar, sadece hedef sembol
    dfs = []
    for f in files:
        try:
            df = pl.read_parquet(
                f,
                columns=["local_ts", "symbol", "type", "bid_price", "bid_qty",
                         "ask_price", "ask_qty", "trade_price", "trade_qty", "is_buyer_maker"]
            )
            filtered = df.filter(pl.col("symbol") == symbol)
            if len(filtered) > 0:
                dfs.append(filtered)
        except Exception as e:
            # trade_price vs yoksa, temel sütunlarla dene
            try:
                df = pl.read_parquet(
                    f,
                    columns=["local_ts", "symbol", "type", "bid_price", "bid_qty",
                             "ask_price", "ask_qty"]
                )
                filtered = df.filter(pl.col("symbol") == symbol)
                if len(filtered) > 0:
                    dfs.append(filtered)
            except Exception as e2:
                logger.warning(f"Dosya atlandı: {os.path.basename(f)} — {e2}")

    if not dfs:
        raise ValueError(f"{symbol} için hiç veri bulunamadı. "
                         f"Mevcut semboller: BTCUSDT, ETHUSDT, SOLUSDT, ...")

    combined = pl.concat(dfs, how="diagonal").sort("local_ts")
    logger.info(f"Toplam {len(combined):,} tick yüklendi.")
    return combined

# ─── SENSİTİVİTE ANALİZİ ────────────────────────────────────────────────────

def run_sensitivity_analysis(
    ticks: pl.DataFrame,
    symbol: str,
    z_range: List[float],
    vpin_range: List[float],
    capital: float = INITIAL_CAPITAL,
) -> List[Dict]:
    """
    Z-Score ve VPIN eşiği kombinasyonları için grid search.
    """
    results = []
    total_combos = len(z_range) * len(vpin_range)
    done = 0

    logger.info(f"Sensitivity analizi başlatıldı: {total_combos} kombinasyon")

    for z in z_range:
        for vp in vpin_range:
            engine = BacktestEngine(
                symbol=symbol,
                z_threshold=z,
                vpin_threshold=vp,
                initial_capital=capital,
            )
            result = engine.run(ticks)
            row = {
                "z_threshold": z,
                "vpin_threshold": vp,
                "total_pnl_usdt": round(result.total_pnl_usdt, 4),
                "total_pnl_pct": round(result.total_pnl_pct, 4),
                "sharpe_ratio": round(result.sharpe_ratio, 4),
                "max_drawdown_pct": round(result.max_drawdown_pct, 4),
                "win_rate_pct": round(result.win_rate_pct, 2),
                "total_trades": result.total_trades,
                "avg_trade_ticks": round(result.avg_trade_ticks, 1),
            }
            results.append(row)
            done += 1
            logger.info(
                f"  [{done}/{total_combos}] Z={z:.1f} VP={vp:.2f} "
                f"| PnL={row['total_pnl_usdt']:+.2f}$ "
                f"| Sharpe={row['sharpe_ratio']:.3f} "
                f"| WR={row['win_rate_pct']:.1f}% "
                f"| Trades={result.total_trades}"
            )

    return results

# ─── WALK-FORWARD VALİDASYON ─────────────────────────────────────────────────

def run_walk_forward(
    ticks: pl.DataFrame,
    symbol: str,
    best_z: float,
    best_vpin: float,
    capital: float = INITIAL_CAPITAL,
) -> Tuple[BacktestResult, BacktestResult]:
    """
    İlk %70 train seti, son %30 test seti.
    """
    n = len(ticks)
    split = int(n * TRAIN_RATIO)
    train_ticks = ticks[:split]
    test_ticks = ticks[split:]

    logger.info(f"Walk-Forward: Train={len(train_ticks):,} ticks, Test={len(test_ticks):,} ticks")

    # Train
    train_engine = BacktestEngine(symbol=symbol, z_threshold=best_z,
                                   vpin_threshold=best_vpin, initial_capital=capital)
    train_result = train_engine.run(train_ticks)
    logger.info(f"  TRAIN → PnL={train_result.total_pnl_usdt:+.2f}$ "
                f"| Sharpe={train_result.sharpe_ratio:.3f} "
                f"| WR={train_result.win_rate_pct:.1f}%")

    # Test (train'de kazanılan sermaye ile devam)
    test_engine = BacktestEngine(symbol=symbol, z_threshold=best_z,
                                  vpin_threshold=best_vpin,
                                  initial_capital=train_result.final_balance)
    test_result = test_engine.run(test_ticks)
    logger.info(f"  TEST  → PnL={test_result.total_pnl_usdt:+.2f}$ "
                f"| Sharpe={test_result.sharpe_ratio:.3f} "
                f"| WR={test_result.win_rate_pct:.1f}%")

    return train_result, test_result

# ─── HTML RAPOR ──────────────────────────────────────────────────────────────

def generate_html_report(
    symbol: str,
    sensitivity: List[Dict],
    train_result: BacktestResult,
    test_result: BacktestResult,
    best_z: float,
    best_vpin: float,
    output_path: str,
):
    """Profesyonel HTML raporu üretir."""

    def sensitivity_rows(data: List[Dict]) -> str:
        rows = []
        for r in sorted(data, key=lambda x: x["total_pnl_usdt"], reverse=True):
            pnl_class = "profit" if r["total_pnl_usdt"] > 0 else "loss"
            rows.append(f"""
            <tr class="{pnl_class}">
                <td>{r['z_threshold']:.1f}</td>
                <td>{r['vpin_threshold']:.2f}</td>
                <td>{r['total_pnl_usdt']:+.2f} $</td>
                <td>{r['total_pnl_pct']:+.2f}%</td>
                <td>{r['sharpe_ratio']:.4f}</td>
                <td>{r['max_drawdown_pct']:.2f}%</td>
                <td>{r['win_rate_pct']:.1f}%</td>
                <td>{r['total_trades']}</td>
                <td>{r['avg_trade_ticks']:.0f}</td>
            </tr>""")
        return "\n".join(rows)

    def trade_rows(trades: List[Trade], limit: int = 50) -> str:
        rows = []
        for t in trades[:limit]:
            cls = "profit" if t.pnl_net > 0 else "loss"
            rows.append(f"""
            <tr class="{cls}">
                <td>{t.side}</td>
                <td>{t.entry_price:.4f}</td>
                <td>{t.exit_price:.4f}</td>
                <td>{t.pnl_net:+.4f} $</td>
                <td>{t.fee_total:.4f} $</td>
                <td>{t.exit_reason}</td>
                <td>{t.exit_tick - t.entry_tick}</td>
                <td>{t.entry_zscore:.3f}</td>
                <td>{t.entry_vpin:.3f}</td>
            </tr>""")
        return "\n".join(rows)

    ts = time.strftime("%Y-%m-%d %H:%M:%S")

    html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Balina-Bot Backtest Report — {symbol}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: #0d1117; color: #c9d1d9; font-family: 'Segoe UI', sans-serif; padding: 24px; }}
  h1 {{ color: #58a6ff; font-size: 2rem; margin-bottom: 8px; }}
  h2 {{ color: #79c0ff; font-size: 1.2rem; margin: 24px 0 12px; border-bottom: 1px solid #30363d; padding-bottom: 6px; }}
  .meta {{ color: #8b949e; font-size: 0.85rem; margin-bottom: 24px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }}
  .card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px; }}
  .card .label {{ font-size: 0.75rem; color: #8b949e; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 6px; }}
  .card .value {{ font-size: 1.4rem; font-weight: 700; }}
  .card .value.pos {{ color: #3fb950; }}
  .card .value.neg {{ color: #f85149; }}
  .card .value.neu {{ color: #d29922; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 0.82rem; margin-bottom: 24px; }}
  th {{ background: #21262d; color: #8b949e; text-align: left; padding: 8px 10px; border-bottom: 1px solid #30363d; }}
  td {{ padding: 6px 10px; border-bottom: 1px solid #21262d; }}
  tr.profit td {{ color: #3fb950; }}
  tr.loss td {{ color: #f85149; }}
  tr:hover {{ background: #161b22; }}
  .badge {{ display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; }}
  .badge.best {{ background: #1f6feb; color: #fff; }}
  .wf-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }}
  .section {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px; }}
  .section h3 {{ color: #79c0ff; margin-bottom: 12px; font-size: 1rem; }}
  .kv {{ display: flex; justify-content: space-between; padding: 4px 0; border-bottom: 1px solid #21262d; }}
  .kv .k {{ color: #8b949e; }}
  .kv .v {{ font-weight: 600; }}
  .v.pos {{ color: #3fb950; }}
  .v.neg {{ color: #f85149; }}
</style>
</head>
<body>

<h1>🐋 Balina-Bot Backtest Report</h1>
<p class="meta">Symbol: <b>{symbol}</b> | Generated: {ts} | Best Params: Z={best_z:.1f}, VPIN={best_vpin:.2f}</p>

<h2>📊 En İyi Parametre ile Özet (Test Seti)</h2>
<div class="grid">
  <div class="card">
    <div class="label">Toplam PnL</div>
    <div class="value {'pos' if test_result.total_pnl_usdt >= 0 else 'neg'}">{test_result.total_pnl_usdt:+.2f} $</div>
  </div>
  <div class="card">
    <div class="label">PnL %</div>
    <div class="value {'pos' if test_result.total_pnl_pct >= 0 else 'neg'}">{test_result.total_pnl_pct:+.2f}%</div>
  </div>
  <div class="card">
    <div class="label">Sharpe Ratio</div>
    <div class="value {'pos' if test_result.sharpe_ratio >= 1 else 'neg' if test_result.sharpe_ratio < 0 else 'neu'}">{test_result.sharpe_ratio:.4f}</div>
  </div>
  <div class="card">
    <div class="label">Max Drawdown</div>
    <div class="value {'pos' if test_result.max_drawdown_pct < 5 else 'neg'}">{test_result.max_drawdown_pct:.2f}%</div>
  </div>
  <div class="card">
    <div class="label">Win Rate</div>
    <div class="value {'pos' if test_result.win_rate_pct >= 50 else 'neg'}">{test_result.win_rate_pct:.1f}%</div>
  </div>
  <div class="card">
    <div class="label">Toplam Trade</div>
    <div class="value neu">{test_result.total_trades}</div>
  </div>
  <div class="card">
    <div class="label">Ort. Trade Süresi</div>
    <div class="value neu">{test_result.avg_trade_ticks:.0f} tick</div>
  </div>
  <div class="card">
    <div class="label">Final Bakiye</div>
    <div class="value pos">{test_result.final_balance:.2f} $</div>
  </div>
</div>

<h2>🔀 Walk-Forward Validation</h2>
<div class="wf-grid">
  <div class="section">
    <h3>🏋️ Train Seti (%70)</h3>
    <div class="kv"><span class="k">PnL</span><span class="v {'pos' if train_result.total_pnl_usdt >= 0 else 'neg'}">{train_result.total_pnl_usdt:+.2f} $</span></div>
    <div class="kv"><span class="k">Sharpe</span><span class="v {'pos' if train_result.sharpe_ratio >= 1 else 'neg'}">{train_result.sharpe_ratio:.4f}</span></div>
    <div class="kv"><span class="k">Max DD</span><span class="v neg">{train_result.max_drawdown_pct:.2f}%</span></div>
    <div class="kv"><span class="k">Win Rate</span><span class="v {'pos' if train_result.win_rate_pct >= 50 else 'neg'}">{train_result.win_rate_pct:.1f}%</span></div>
    <div class="kv"><span class="k">Trades</span><span class="v neu">{train_result.total_trades}</span></div>
    <div class="kv"><span class="k">Final Bakiye</span><span class="v pos">{train_result.final_balance:.2f} $</span></div>
  </div>
  <div class="section">
    <h3>🧪 Test Seti (%30) — OOS</h3>
    <div class="kv"><span class="k">PnL</span><span class="v {'pos' if test_result.total_pnl_usdt >= 0 else 'neg'}">{test_result.total_pnl_usdt:+.2f} $</span></div>
    <div class="kv"><span class="k">Sharpe</span><span class="v {'pos' if test_result.sharpe_ratio >= 1 else 'neg'}">{test_result.sharpe_ratio:.4f}</span></div>
    <div class="kv"><span class="k">Max DD</span><span class="v neg">{test_result.max_drawdown_pct:.2f}%</span></div>
    <div class="kv"><span class="k">Win Rate</span><span class="v {'pos' if test_result.win_rate_pct >= 50 else 'neg'}">{test_result.win_rate_pct:.1f}%</span></div>
    <div class="kv"><span class="k">Trades</span><span class="v neu">{test_result.total_trades}</span></div>
    <div class="kv"><span class="k">Final Bakiye</span><span class="v pos">{test_result.final_balance:.2f} $</span></div>
  </div>
</div>

<h2>🔬 Sensitivity Analizi — Tüm Parametre Kombinasyonları</h2>
<table>
  <thead>
    <tr>
      <th>Z-Eşik</th><th>VPIN-Eşik</th><th>PnL ($)</th><th>PnL (%)</th>
      <th>Sharpe</th><th>Max DD</th><th>Win Rate</th><th>Trades</th><th>Ort. Tick</th>
    </tr>
  </thead>
  <tbody>
    {sensitivity_rows(sensitivity)}
  </tbody>
</table>

<h2>📋 Trade Detayları (Test Seti — İlk 50)</h2>
<table>
  <thead>
    <tr>
      <th>Yön</th><th>Giriş</th><th>Çıkış</th><th>Net PnL</th>
      <th>Fee</th><th>Neden</th><th>Süre</th><th>Z-Score</th><th>VPIN</th>
    </tr>
  </thead>
  <tbody>
    {trade_rows(test_result.trades)}
  </tbody>
</table>

<p class="meta" style="margin-top:24px;">⚠️ Bu rapor geçmiş veriye dayalıdır. Gelecekteki performansı garanti etmez.</p>
</body>
</html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    logger.info(f"HTML raporu kaydedildi: {output_path}")

# ─── SONUÇLARI KAYDET ────────────────────────────────────────────────────────

def save_results(
    sensitivity: List[Dict],
    train_result: BacktestResult,
    test_result: BacktestResult,
    symbol: str,
    best_z: float,
    best_vpin: float,
):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")

    # Sensitivity Parquet
    sens_df = pl.DataFrame(sensitivity)
    sens_path = os.path.join(RESULTS_DIR, f"sensitivity_{symbol}_{ts}.parquet")
    sens_df.write_parquet(sens_path)
    logger.info(f"Sensitivity Parquet: {sens_path}")

    # Trade detayları Parquet (test seti)
    if test_result.trades:
        trade_dicts = [asdict(t) for t in test_result.trades]
        trade_df = pl.DataFrame(trade_dicts)
        trades_path = os.path.join(RESULTS_DIR, f"trades_test_{symbol}_{ts}.parquet")
        trade_df.write_parquet(trades_path)
        logger.info(f"Trade Parquet: {trades_path}")

    # HTML rapor
    html_path = os.path.join(RESULTS_DIR, f"report_{symbol}_{ts}.html")
    generate_html_report(
        symbol=symbol,
        sensitivity=sensitivity,
        train_result=train_result,
        test_result=test_result,
        best_z=best_z,
        best_vpin=best_vpin,
        output_path=html_path,
    )

    # Özet JSON
    summary = {
        "symbol": symbol,
        "timestamp": ts,
        "best_z_threshold": best_z,
        "best_vpin_threshold": best_vpin,
        "train": {
            "pnl_usdt": train_result.total_pnl_usdt,
            "pnl_pct": train_result.total_pnl_pct,
            "sharpe": train_result.sharpe_ratio,
            "max_dd": train_result.max_drawdown_pct,
            "win_rate": train_result.win_rate_pct,
            "trades": train_result.total_trades,
        },
        "test": {
            "pnl_usdt": test_result.total_pnl_usdt,
            "pnl_pct": test_result.total_pnl_pct,
            "sharpe": test_result.sharpe_ratio,
            "max_dd": test_result.max_drawdown_pct,
            "win_rate": test_result.win_rate_pct,
            "trades": test_result.total_trades,
        },
    }
    json_path = os.path.join(RESULTS_DIR, f"summary_{symbol}_{ts}.json")
    with open(json_path, "w") as f:
        json.dump(summary, f, indent=2)
    logger.info(f"Ozet JSON: {json_path}")

    return html_path

# ─── MAIN ────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Balina-Bot Backtest Engine v1.0")
    parser.add_argument("--symbol",    default="BTCUSDT",  help="Backtest sembolü")
    parser.add_argument("--max-files", type=int, default=None, help="Maksimum Parquet dosya sayısı")
    parser.add_argument("--capital",   type=float, default=INITIAL_CAPITAL, help="Başlangıç sermayesi (USDT)")
    parser.add_argument("--fast",      action="store_true", help="Hızlı mod: sensitivity analizi atlanır")
    args = parser.parse_args()

    t_start = time.time()
    logger.info("=" * 70)
    logger.info("BALINA-BOT BACKTEST ENGINE v1.0")
    logger.info("=" * 70)

    # ── Veri Yükleme ──
    ticks = load_data(symbol=args.symbol, max_files=args.max_files)

    if len(ticks) < MIN_TICKS_REQUIRED:
        logger.error(f"Yeterli veri yok: {len(ticks):,} < {MIN_TICKS_REQUIRED:,}")
        sys.exit(1)

    # ── Sensitivity Analizi ──
    if not args.fast:
        z_range   = [3.0, 4.5, 6.0]
        vpin_range = [0.50, 0.65, 0.80]
    else:
        logger.info("Hızlı mod: sensitivity analizi atlanıyor.")
        z_range   = [4.5]
        vpin_range = [0.65]

    sensitivity = run_sensitivity_analysis(
        ticks=ticks, symbol=args.symbol,
        z_range=z_range, vpin_range=vpin_range,
        capital=args.capital,
    )

    # ── En İyi Parametreyi Seç ──
    best = max(sensitivity, key=lambda x: x["sharpe_ratio"])
    best_z    = best["z_threshold"]
    best_vpin = best["vpin_threshold"]
    logger.info(f"\nEN İYİ PARAMETRE: Z={best_z:.1f} | VPIN={best_vpin:.2f} "
                f"| Sharpe={best['sharpe_ratio']:.4f} | PnL={best['total_pnl_usdt']:+.2f}$")

    # ── Walk-Forward Validation ──
    logger.info("\nWalk-Forward Validation başlatılıyor...")
    train_result, test_result = run_walk_forward(
        ticks=ticks, symbol=args.symbol,
        best_z=best_z, best_vpin=best_vpin,
        capital=args.capital,
    )

    # ── Sonuçları Kaydet ──
    logger.info("\nSonuçlar kaydediliyor...")
    html_path = save_results(
        sensitivity=sensitivity,
        train_result=train_result,
        test_result=test_result,
        symbol=args.symbol,
        best_z=best_z,
        best_vpin=best_vpin,
    )

    elapsed = time.time() - t_start
    logger.info("=" * 70)
    logger.info(f"BACKTEST TAMAMLANDI — {elapsed:.1f}s")
    logger.info(f"HTML Rapor: {os.path.abspath(html_path)}")
    logger.info("=" * 70)


if __name__ == "__main__":
    main()
