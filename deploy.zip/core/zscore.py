from collections import deque
import math
from core.logger_factory import get_logger
logger = get_logger("ZScore")

class RollingZScore:
    """
    Computes expanding/rolling Mean Reversion logic within fixed collections.deque
    to cap memory while analyzing HFT streams.
    """
    __slots__ = ["window_size", "prices", "_sum", "_sum_sq", "recalc_counter"]
    
    def __init__(self, window_size: int = 3000):
        self.window_size = window_size
        self.prices = deque(maxlen=window_size)
        self._sum = 0.0
        self._sum_sq = 0.0
        self.recalc_counter = 0

    def add_price(self, price: float) -> float:
        """
        Ingests a new price, efficiently updates running sum and sum of squares O(1),
        and returns the current Z-Score.
        Returns 0.0 if not enough data.
        """
        if len(self.prices) == self.window_size:
            oldest = self.prices[0]
            self._sum -= oldest
            self._sum_sq -= (oldest * oldest)
            
        self.prices.append(price)
        self._sum += price
        self._sum_sq += (price * price)
        
        self.recalc_counter += 1
        if self.recalc_counter >= self.window_size:
            self._sum = math.fsum(self.prices)
            self._sum_sq = math.fsum(x*x for x in self.prices)
            self.recalc_counter = 0
        n = len(self.prices)
        if n < 2:
            return 0.0
            
        import statistics
        try:
            mean = statistics.mean(self.prices)
            std_dev = statistics.stdev(self.prices)
        except statistics.StatisticsError:
            return 0.0
            
        if std_dev == 0.0:
            return 0.0
            
        z_score = (price - mean) / std_dev
        
        # DEBUG TRACE
        if self.recalc_counter % 500 == 0:
            logger.info(f"ZDEBUG -> N: {n}, Mean: {mean:.2f}, Std: {std_dev:.5f}, Price: {price}, Z: {z_score:.2f}")
            
        return z_score
