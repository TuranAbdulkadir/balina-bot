class VPIN:
    """
    Volume-Synchronized Probability of Informed Trading (VPIN)
    Identifies toxic whale flows by slicing aggregate flow into fixed Volume Buckets.
    """
    __slots__ = ["bucket_size", "current_bucket_vol", "current_buy_vol", "current_sell_vol", "vpin_threshold", "vpin"]
    
    def __init__(self, bucket_size: float = 100.0, vpin_threshold: float = 0.75):
        self.bucket_size = float(max(0.001, bucket_size))
        self.current_bucket_vol = 0.0
        self.current_buy_vol = 0.0
        self.current_sell_vol = 0.0
        self.vpin_threshold = float(max(0.01, min(1.0, vpin_threshold)))
        self.vpin: float = 0.0  # Latest computed VPIN ratio for external readers

    def add_trade(self, qty: float, is_buyer_maker: bool) -> bool:
        """
        Adds trade volume into buckets.
        is_buyer_maker=True -> Taker was a SELLER (Aggressive Sell Flow).
        is_buyer_maker=False -> Taker was a BUYER (Aggressive Buy Flow).
        Returns True if TOXIC SELL FLOW is detected inside the bucket.
        """
        self.current_bucket_vol += qty
        
        if is_buyer_maker:
            self.current_sell_vol += qty
        else:
            self.current_buy_vol += qty
            
        if self.current_bucket_vol >= self.bucket_size:
            sell_ratio = self.current_sell_vol / self.current_bucket_vol
            self.vpin = sell_ratio  # Store latest VPIN for external access
            
            self.current_bucket_vol = 0.0
            self.current_buy_vol = 0.0
            self.current_sell_vol = 0.0
            
            if sell_ratio > self.vpin_threshold:
                return True
                
        return False
