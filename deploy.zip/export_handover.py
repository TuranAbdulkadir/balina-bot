import os

files_to_read = [
    'main.py',
    'core/config.py',
    'core/logger_factory.py',
    'core/mathematics.py',
    'core/kelly_manager.py',
    'core/symbol_selector.py',
    'core/trend_filter.py',
    'core/simulation_reporter.py',
    'core/ml_optimizer.py',
    'network/http_client.py',
    'network/ws_client.py',
    'network/user_ws.py',
    'network/funding.py',
    'network/telegram_bot.py',
    'orderbook/lob.py',
    'execution/engine.py',
    'execution/strategy_alpha.py'
]

output_file = 'project_handover_prompt.txt'

summary = """# KRİPTO TRADING BOT PROJESİ - KAPSAMLI ÖZET VE KODLAR

Bu doküman, şu ana kadar geliştirdiğimiz asenkron HFT Kripto Trading Bot projesinin tam mimarisini, stratejisini, yaşanan sorunları ve güncel kodlarını içermektedir. Yeni AI asistanının projeye tam hakim olması için hazırlanmıştır.

## 1. BOT MİMARİSİ
- **Dil ve Framework:** Python 3.13. Tamamen asenkron mimari (asyncio, aiohttp).
- **Tasarım Felsefesi:** Bare-metal. ccxt gibi ağır kütüphaneler KULLANILMAMIŞTIR. API bağlantıları, LOB (Limit Order Book) yönetimi ve Ed25519 asimetrik şifrelemeleri sıfırdan yazılmıştır.
- **Kütüphaneler:** aiohttp (ağ istekleri), pandas, pyarrow (Data Lake parquet yönetimi), xgboost, scikit-learn, numpy (ML optimizasyonu), cryptography (API şifreleme).
- **Dosya Yapısı:** Modüler yapıdadır. main.py merkezli olup core/, network/, execution/, ve orderbook/ klasörlerine ayrılmıştır.

## 2. STRATEJİ
- **Tür:** Tick-level Scalping ve Mean Reversion (Ortalamaya Dönüş).
- **Sinyaller ve İndikatörler:** 
  - **Z-Score:** LOB üzerinden hesaplanan Volume-Weighted Micro-Price (VWMP) sapmalarını ölçer. Fiyat ortalamadan çok saparsa ters yöne (Mean Reversion) pozisyon açılır.
  - **OBI (Order Book Imbalance):** Emir defterindeki alıcı/satıcı baskısı.
  - **VPIN:** Toksik akış tespiti (Piyasa manipülasyonlarına karşı koruma).
  - **Trend Filter (EMA-21 & VWAP):** 15 dakikalık makro trendi izler. Makro trende ters düşen Z-Score sinyallerini filtreler.
- **Zaman Dilimi:** LOB üzerinden her 100 milisaniyede bir (Tick-Level) akan veri ile anlık karar verilir.
- **Risk Yönetimi (Stop-Loss / Take-Profit):**
  - **Kelly Kriteri:** Kasa boyutuna göre dinamik pozisyon büyüklüğü (Maksimum %15 fraksiyon, max 5x kaldıraç).
  - **Breakeven + 1 Tick Take Profit:** Komisyon (Fee) hesaplanarak fiyat kara geçtiği an pozisyon anında terk edilir.
  - **Trailing Stop:** Pozisyon kâra geçerse zirve noktadan %10'luk geri çekilmede kapanır.
  - **Max Drawdown Kilidi:** Entry price'dan %0.8 ters gidilirse pozisyon acil olarak (Emergency Market Exit) kapatılır.
  - **Zaman Kilidi (Time Lock):** Bir pozisyon 300 saniyeden (5 dakika) uzun açık kalırsa kapatılır.
  - **Funding Rate Koruması:** Pozisyon açmadan önce anlık funding rate'e bakılır. Aleyhte ise işleme girilmez.
  - **Günlük Zarar Limiti:** Kasanın %3'ü kaybedilirse bot kendini SHUTDOWN_LOCK.txt ile kilitler ve PM2'nin yeniden başlatmasını engeller.

## 3. BORSA & API
- **Borsa:** Binance Futures (U-M).
- **Endpoint Mimarisi:** Dual-Endpoint (Aşama 13). Canlı piyasa verileri gerçek fstream.binance.com WebSocket'inden akar. Emirler ise testnet.binancefuture.com adresine gider. Bu sayede bot canlı veriyi simüle ederek testnet üzerinde güvenle işlem yapar.
- **Bağlantı ve Şifreleme:** Ed25519 asimetrik şifreleme ile bare-metal REST API istekleri gönderilir.

## 4. BACKTEST & SONUÇLAR
- **Yaşanan Büyük Zarar:** Projenin önceki aşamalarında, Binance hesabının Hedge Modunda kalması nedeniyle -4061 (Order's position side does not match) hatası alındı. Ayrıca makro trend filtresi eksikliği sebebiyle devasa scam-wick'lerde terse düşülerek kasanın %50'si kaybedildi.
- **Çözüm:** Bu zarardan sonra bot tamamen Testnet ve Dry-Run (Sanal İşlem) moduna alındı. 
- **Veri Kayıtları:** Bot, simülasyondaki (Dry-Run) işlemlerini simulation_reporter.py ile CSV dosyasına kaydetmekte ve Win Rate, Net PnL, Slippage gibi metrikleri Telegram botu üzerinden bildirmektedir.

## 5. SON DURUM
- **Mevcut Aşama:** Projedeki tüm kritik zırhlar (Trend Filtresi, Dinamik Sembol Geçişi, Offline ML Z-Score Optimizasyonu, Funding Rate Zırhı, Telegram İnteraktif Yönetim) tamamlanmıştır.
- **Eksikler/Sorunlar:** Kod mimarisi tamamlandı, çözülemeyen bir hata kalmadı. Bot şu an canlı verilerle Testnet üzerinde simülasyon/test sürecindedir.

## 6. MEVCUT KODLAR (TÜM DOSYALAR)

"""

with open(output_file, 'w', encoding='utf-8') as f:
    f.write(summary)
    for file_path in files_to_read:
        if os.path.exists(file_path):
            f.write(f'### Dosya: {file_path}\n```python\n')
            with open(file_path, 'r', encoding='utf-8') as code_file:
                f.write(code_file.read())
            f.write('\n```\n\n')
        else:
            f.write(f'### Dosya: {file_path} (BULUNAMADI)\n\n')

print(f"Rapor {output_file} dosyasina basariyla yazildi.")
