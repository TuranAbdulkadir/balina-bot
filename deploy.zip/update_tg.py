import os

path = os.path.expanduser('~/balina_bot/network/telegram.py')
with open(path, 'r', encoding='utf-8') as f:
    code = f.read()

new_code = code.replace(
    'asyncio.create_task(self.panic_exit())',
    '''asyncio.create_task(self.panic_exit())
                                elif text == "/RAPOR" and user_id == self.allowed_user:
                                    asyncio.create_task(self.send_report())'''
)

report_method = '''
    async def send_report(self):
        try:
            import os
            import subprocess
            files = os.listdir("core/data_lake") if os.path.exists("core/data_lake") else []
            lake_size = len(files) * 5000
            
            # Pack zip
            if lake_size > 0:
                subprocess.run("zip -r data_lake_backup.zip core/data_lake -q", shell=True)
                msg_text = f"📊 **Balina-Bot Raporu**\\n- �slem Goren LOB Verisi: ~{lake_size}\\n- Parquet Dosya Sayisi: {len(files)}\\n\\nWARM-UP Modu basariyla pazar verisi kaydediyor."
                
                # Send text and document
                import aiohttp
                async with aiohttp.ClientSession() as session:
                    url = f"{self.base_url}/sendMessage"
                    await session.post(url, data={"chat_id": self.allowed_user, "text": msg_text})
                    
                    url_doc = f"{self.base_url}/sendDocument"
                    with open("data_lake_backup.zip", "rb") as f:
                        await session.post(url_doc, data={"chat_id": self.allowed_user, "document": f})
            else:
                msg_text = "Henuz Data Lake icerisinde birikmis kayit bulunmuyor. Makine isiniyor..."
                import aiohttp
                async with aiohttp.ClientSession() as session:
                    url = f"{self.base_url}/sendMessage"
                    await session.post(url, data={"chat_id": self.allowed_user, "text": msg_text})
        except Exception as e:
            logger.error(f"Rapor gonderme basarisiz: {e}")
'''

# ensure we only append once
if "def send_report" not in new_code:
    new_code += report_method

with open(path, 'w', encoding='utf-8') as f:
    f.write(new_code)
print("Telegram updated!")
