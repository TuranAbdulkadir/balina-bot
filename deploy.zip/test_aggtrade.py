"""Test aggTrade stream ALONE."""
import asyncio, aiohttp, json, time

async def main():
    count = 0
    url = "wss://fstream.binance.com/ws/btcusdt@aggTrade"
    
    async with aiohttp.ClientSession() as session:
        async with session.ws_connect(url, receive_timeout=10.0) as ws:
            print(f"Connected to {url}")
            start = time.time()
            async for msg in ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    count += 1
                    if count == 1:
                        print(f"FIRST: {json.dumps(data)[:200]}")
                if time.time() - start > 5.0:
                    break
    
    print(f"\naggTrade count in 5 seconds: {count}")

asyncio.run(main())
