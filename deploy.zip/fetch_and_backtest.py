import requests
import pandas as pd
import numpy as np
import time
import os

DATA_FILE = "backtest_data/BTCUSDT_5m_180d.parquet"

# AŞAMA 29.2: Strateji Parametreleri
EMA_SHORT = 21
EMA_LONG = 50
RSI_PERIOD = 14
RSI_BUY_MIN = 60
RSI_SELL_MAX = 40
TAKE_PROFIT_PCT = 0.015
STOP_LOSS_PCT = 0.005
VOLUME_MULTIPLIER = 2.0

# Cüzdan Parametreleri
INITIAL_BALANCE = 300.0
LEVERAGE = 2.0
FEE = 0.0004
SLIPPAGE = 0.0001

def fetch_data():
    if os.path.exists(DATA_FILE):
        print(f"Data file already exists: {DATA_FILE}")
        return pd.read_parquet(DATA_FILE)
        
    print("Fetching 180 days of 5m data from Binance...")
    all_data = []
    end_time = int(time.time() * 1000)
    start_time = end_time - (180 * 24 * 60 * 60 * 1000)
    
    current_start = start_time
    while current_start < end_time:
        url = f"https://fapi.binance.com/fapi/v1/klines?symbol=BTCUSDT&interval=5m&limit=1000&startTime={current_start}&endTime={end_time}"
        resp = requests.get(url)
        data = resp.json()
        
        if not data:
            break
            
        all_data.extend(data)
        current_start = data[-1][0] + 1  # Next candle start time
        print(f"Fetched {len(all_data)} candles...")
        time.sleep(0.5) # Rate limit protection
        
    df = pd.DataFrame(all_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'qav', 'num_trades', 'taker_base_vol', 'taker_quote_vol', 'ignore'])
    df = df.drop_duplicates(subset=['timestamp']).sort_values('timestamp').reset_index(drop=True)
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = df[col].astype(float)
        
    df.to_parquet(DATA_FILE, engine='pyarrow')
    print(f"Saved {len(df)} candles to {DATA_FILE}")
    return df

def calc_ema(series, period):
    return series.ewm(span=period, adjust=False).mean()

def calc_rsi(series, period):
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def calc_adx(high, low, close, period=14):
    df = pd.DataFrame({'high': high, 'low': low, 'close': close})
    df['tr0'] = abs(df['high'] - df['low'])
    df['tr1'] = abs(df['high'] - df['close'].shift())
    df['tr2'] = abs(df['low'] - df['close'].shift())
    df['tr'] = df[['tr0', 'tr1', 'tr2']].max(axis=1)

    df['up_move'] = df['high'] - df['high'].shift()
    df['down_move'] = df['low'].shift() - df['low']

    df['+dm'] = np.where((df['up_move'] > df['down_move']) & (df['up_move'] > 0), df['up_move'], 0)
    df['-dm'] = np.where((df['down_move'] > df['up_move']) & (df['down_move'] > 0), df['down_move'], 0)

    df['tr_sm'] = df['tr'].ewm(alpha=1/period, adjust=False).mean()
    df['+dm_sm'] = df['+dm'].ewm(alpha=1/period, adjust=False).mean()
    df['-dm_sm'] = df['-dm'].ewm(alpha=1/period, adjust=False).mean()

    df['+di'] = 100 * (df['+dm_sm'] / df['tr_sm'])
    df['-di'] = 100 * (df['-dm_sm'] / df['tr_sm'])
    
    df['dx'] = 100 * abs(df['+di'] - df['-di']) / (df['+di'] + df['-di'])
    df['adx'] = df['dx'].ewm(alpha=1/period, adjust=False).mean()
    
    return df['adx']

def run_simulation(df_subset, label):
    balance = INITIAL_BALANCE
    pos_type = 0 # 1 long, -1 short, 0 none
    entry_price = 0
    trade_history = []
    equity_curve = [INITIAL_BALANCE]
    
    for i in range(50, len(df_subset)):
        close = df_subset['close'].iloc[i]
        
        ema_short = df_subset['ema_short'].iloc[i]
        ema_long = df_subset['ema_long'].iloc[i]
        prev_ema_short = df_subset['ema_short'].iloc[i-1]
        prev_ema_long = df_subset['ema_long'].iloc[i-1]
        rsi = df_subset['rsi'].iloc[i]
        adx = df_subset['adx'].iloc[i]
        vol = df_subset['volume'].iloc[i]
        vol_sma20 = df_subset['vol_sma20'].iloc[i]
        
        bullish = ema_short > ema_long
        bearish = ema_short < ema_long
        cross_up = prev_ema_short <= prev_ema_long and ema_short > ema_long
        cross_down = prev_ema_short >= prev_ema_long and ema_short < ema_long
        vol_ok = vol > vol_sma20 * VOLUME_MULTIPLIER
        
        if pos_type != 0:
            pnl_pct = (close - entry_price) / entry_price if pos_type == 1 else (entry_price - close) / entry_price
            exit_reason = None
            if pnl_pct >= TAKE_PROFIT_PCT: exit_reason = "TP"
            elif pnl_pct <= -STOP_LOSS_PCT: exit_reason = "SL"
            elif pos_type == 1 and cross_down: exit_reason = "REVERSAL"
            elif pos_type == -1 and cross_up: exit_reason = "REVERSAL"
            
            if exit_reason:
                exit_price = close * (1 - SLIPPAGE) if pos_type == 1 else close * (1 + SLIPPAGE)
                gross_pnl_pct = (exit_price - entry_price) / entry_price if pos_type == 1 else (entry_price - exit_price) / entry_price
                trade_value = balance * LEVERAGE
                fee_cost = trade_value * FEE * 2
                net_pnl = (trade_value * gross_pnl_pct) - fee_cost
                balance += net_pnl
                trade_history.append({"reason": exit_reason, "pnl": net_pnl, "pnl_pct": gross_pnl_pct, "entry": entry_price, "exit": exit_price, "type": "LONG" if pos_type == 1 else "SHORT"})
                pos_type = 0
                equity_curve.append(balance)
        
        if pos_type == 0 and adx > 25.0:
            if bullish and rsi > RSI_BUY_MIN and vol_ok:
                pos_type = 1
                entry_price = close * (1 + SLIPPAGE)
            elif bearish and rsi < RSI_SELL_MAX and vol_ok:
                pos_type = -1
                entry_price = close * (1 - SLIPPAGE)

    print(f"\n--- {label} ---")
    print(f"Total Trades: {len(trade_history)}")
    if len(trade_history) < 50:
        print("WARNING: Total trades are less than 50!")
        
    if len(trade_history) > 0:
        wins = [t for t in trade_history if t['pnl'] > 0]
        win_rate = len(wins) / len(trade_history) * 100
        returns = pd.Series(equity_curve).pct_change().dropna()
        sharpe = (returns.mean() / returns.std() * np.sqrt(252 * 288)) if returns.std() != 0 else 0
        peak = pd.Series(equity_curve).cummax()
        drawdown = (pd.Series(equity_curve) - peak) / peak
        max_dd = drawdown.min() * 100
        
        print(f"Total PnL: {balance - INITIAL_BALANCE:.2f} USDT (Ending Balance: {balance:.2f})")
        print(f"Win Rate: {win_rate:.2f}%")
        print(f"Sharpe Ratio: {sharpe:.2f}")
        print(f"Max Drawdown: {max_dd:.2f}%")
    return trade_history

def regime_analysis(df, trades):
    print("\n--- Piyasa Rejimi Analizi ---")
    # Böl: df'yi 3 parçaya böl (180 günlük veri)
    part_size = len(df) // 3
    parts = []
    
    # Calculate returns to classify regime
    for i in range(3):
        start_idx = i * part_size
        end_idx = start_idx + part_size if i < 2 else len(df)
        df_part = df.iloc[start_idx:end_idx]
        start_price = df_part['close'].iloc[0]
        end_price = df_part['close'].iloc[-1]
        pct_change = (end_price - start_price) / start_price * 100
        
        if pct_change >= 10:
            regime = "Strong Uptrend"
        elif pct_change <= -10:
            regime = "Strong Downtrend"
        else:
            regime = "Sideways"
            
        start_time = df_part['timestamp'].iloc[0]
        end_time = df_part['timestamp'].iloc[-1]
        
        # Find trades in this timeframe
        regime_trades = [t for t in trades if t.get('entry_time', start_time) >= start_time and t.get('entry_time', end_time) <= end_time]
        
        # Since our trades don't have entry_time right now, let's just do a rough mapping or run the simulation on the part directly
        parts.append((regime, pct_change, start_idx, end_idx))
        
    for regime_name, pct_change, start_idx, end_idx in parts:
        print(f"\nRegime: {regime_name} (BTC Change: {pct_change:.2f}%)")
        run_simulation(df.iloc[start_idx:end_idx], f"{regime_name} Period")


def main():
    df = fetch_data()
    
    # Calculate indicators on FULL data
    df['ema_short'] = calc_ema(df['close'], EMA_SHORT)
    df['ema_long'] = calc_ema(df['close'], EMA_LONG)
    df['rsi'] = calc_rsi(df['close'], RSI_PERIOD)
    df['adx'] = calc_adx(df['high'], df['low'], df['close'], 14)
    df['vol_sma20'] = df['volume'].rolling(window=20).mean()
    
    # Walk-forward splits (180 days total)
    # Train: First 120 days
    # Test: Last 60 days
    total_candles = len(df)
    train_size = int(total_candles * (120/180))
    
    df_train = df.iloc[:train_size].copy()
    df_test = df.iloc[train_size:].copy()
    
    print(f"\nData split: Train {len(df_train)} candles (120 days), Test {len(df_test)} candles (60 days)")
    
    train_trades = run_simulation(df_train, "TRAIN SET (120 Days)")
    test_trades = run_simulation(df_test, "TEST SET (60 Days)")
    
    # Rejim analizi
    regime_analysis(df, []) # passing full df

if __name__ == "__main__":
    main()
