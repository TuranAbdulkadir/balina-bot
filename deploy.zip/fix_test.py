import asyncio
import sys
import os
sys.path.append('/home/ubuntu/balina_bot')

# Manually load keys
keys = {}
with open('/home/ubuntu/balina_bot/.env') as f:
    for line in f:
        if '=' in line and not line.startswith('#'):
            k, v = line.strip().split('=', 1)
            keys[k] = v.strip('"\'')

from network.http_client import BinanceHTTPClient

async def f():
    client = BinanceHTTPClient(keys.get('BINANCE_API_KEY'), keys.get('BINANCE_ED25519_PRIVATE_KEY'))
    print(await client.get_signed('/fapi/v1/positionSide/dual'))
    try:
        print(await client.post_signed('/fapi/v1/positionSide/dual', {'dualSidePosition': 'false'}))
    except Exception as e:
        print("Error:", e)
    print(await client.get_signed('/fapi/v1/positionSide/dual'))

asyncio.run(f())
