import re
with open('bot-out.log', encoding='utf-8', errors='ignore') as f:
    lines = f.readlines()
for l in lines[-75000:]:
    if 'BinanceAPIException' in l or 'ERROR' in l:
        if 'code=' in l or 'message=' in l or 'Bad Request' in l or 'Precision' in l:
            print(l.strip())
