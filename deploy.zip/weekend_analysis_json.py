import pandas as pd
import glob
import sys

files = sorted(glob.glob("/home/ubuntu/balina_bot/core/data_lake/*.parquet"))[-200:]
if not files: sys.exit(0)

dfs = []
for f in files:
    try: dfs.append(pd.read_parquet(f))
    except: pass

master_df = pd.concat(dfs, ignore_index=True)
mid_price = (master_df["best_bid"] + master_df["best_ask"]) / 2.0
spreads = master_df["best_ask"] - master_df["best_bid"]
min_price = mid_price.min()
max_price = mid_price.max()
price_range = ((max_price - min_price) / min_price) * 100
toxic_flags = (master_df["vpin"] > 0.8).sum()

zscore = master_df["zscore"]
panic_long = (zscore < -4.5).sum()
panic_short = (zscore > 4.5).sum()
good_entries = ((zscore > 2.0) | (zscore < -2.0)).sum()

print(f"[{len(master_df)} Ticks] | Min: ${min_price:.2f} | Max: ${max_price:.2f} | Volatility: {price_range:.2f}%")
print(f"Spread Avg: ${spreads.mean():.2f} | Toxic Ticks: {toxic_flags}")
print(f"Signals (Z>2): {good_entries} | Black Swans Long: {panic_long} | Black Swans Short: {panic_short}")
