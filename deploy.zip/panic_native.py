import asyncio
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from network.http_client import BinanceRestClient

async def panic():
    print("🚨 EMERGENCY CLOSE: CANCELLING ALL ORDERS AND POSITIONS 🚨")
    client = BinanceRestClient()
    try:
        res = await client.delete_signed("/fapi/v1/allOpenOrders", {"symbol": "BTCUSDT"})
        print("Orders Canceled:", res)
        pos = await client.get_signed("/fapi/v2/positionRisk", {"symbol": "BTCUSDT"})
        for p in pos:
            amt = float(p.get("positionAmt", "0"))
            if amt != 0:
                side = "BUY" if amt < 0 else "SELL"
                print(f"Closing {amt} BTCUSDT via {side} MARKET...")
                out = await client.post_signed("/fapi/v1/order", {
                    "symbol": "BTCUSDT",
                    "side": side,
                    "type": "MARKET",
                    "quantity": str(abs(amt))
                })
                print("Exit:", out)
    except Exception as e:
        print("Error:", e)
    finally:
        await client.session.close()

if __name__ == "__main__":
    asyncio.run(panic())
