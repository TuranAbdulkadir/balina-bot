"""
BALINA-BOT  —  AŞAMA 29: EMA Crossover + RSI Trend Following Strategy
======================================================================
Eski Z-Score / VPIN / OBI mikro-scalping mantığı KÖK NEDEN ANALİZİ
sonucunda tamamen kaldırıldı.  Fee bariyerini (%0.06 round-trip) rahatlıkla
aşabilecek 1-dakikalık mum (kline) bazlı Trend Following stratejisine
geçildi.

GİRİŞ:  EMA9 x EMA21 Crossover  +  RSI Momentum Filtresi  +  Hacim Patlaması
ÇIKIŞ:  TP %0.8  |  SL %0.4  |  Trend Dönüşü  |  Funding Saati Kalkanı
"""

import asyncio
import time
import os
import math
from decimal import Decimal, ROUND_DOWN
from collections import deque
from typing import List, Optional

from core.logger_factory import get_logger
from core.config import (
    WARMUP_MODE, DRY_RUN,
    MAX_POSITION_HOLD_SECONDS, MAX_DRAWDOWN_PCT,
    EMA_SHORT, EMA_LONG, RSI_PERIOD,
    RSI_BUY_MIN, RSI_SELL_MAX,
    TAKE_PROFIT_PCT, STOP_LOSS_PCT,
    KLINE_WARMUP_COUNT,
)
from core.kelly_manager import KellyRiskManager

logger = get_logger("StrategyAlpha")

# ═══════════════════════════════════════════════════════════
# IRON CONSTANTS — Absolute Hard Limits (Korunuyor)
# ═══════════════════════════════════════════════════════════
MAX_POSITION_BTC = Decimal("0.001")
DAILY_LOSS_PCT = Decimal("0.03")
MDD_HARD_STOP_PCT = Decimal("0.15")
COOLDOWN_AFTER_LOSS_SEC = 30.0
MIN_VOLUME_MULTIPLIER = 1.5          # Son mum hacmi > SMA20 * 1.5


class AlphaStrategy:
    """1-Dakika Kline bazlı EMA Crossover + RSI Trend Following."""

    # ──────────────────────────────────────────────────────
    # __init__
    # ──────────────────────────────────────────────────────
    def __init__(self, engine, lob, reporter=None, trend_filter=None, funding_monitor=None):
        self.engine = engine
        self.lob = lob
        self.reporter = reporter
        self.trend_filter = trend_filter
        self.funding_monitor = funding_monitor

        # Kelly Risk Manager
        self.kelly = KellyRiskManager(
            kelly_fraction="0.15", max_leverage="5.0", reporter=self.reporter
        )

        # ── Kline (1m) veri tamponları ──
        self.closes: deque = deque(maxlen=200)
        self.highs: deque = deque(maxlen=200)
        self.lows: deque = deque(maxlen=200)
        self.volumes: deque = deque(maxlen=200)
        self.kline_ready: bool = False      # Warmup bitene kadar False

        # ── İndikatör önbellekleri ──
        self._ema_short: float = 0.0
        self._ema_long: float = 0.0
        self._prev_ema_short: float = 0.0   # Crossover tespiti için
        self._prev_ema_long: float = 0.0
        self._last_rsi: float = 50.0
        self._last_signal: str = "NONE"     # BUY / SELL / NONE

        # ── Pozisyon takibi ──
        self.sim_pos_amt = Decimal("0")
        self.sim_entry_price = Decimal("0")
        self.sim_side = ""
        self.sim_qty = Decimal("0")
        self.position_open_time: float = 0.0
        self.peak_pnl = Decimal("0")

        # ── Risk state ──
        self.daily_pnl = Decimal("0")
        self.daily_reset_time = time.time()
        self.last_exit_time: float = 0.0
        self.consecutive_losses: int = 0
        self.trade_history: deque = deque(maxlen=50)

        # ── Pause / Lock ──
        self.paused: bool = False
        self.data_lake_path = "core/data_lake"

        # ── Tick sayacı (LOB telemetri) ──
        self.tick_count: int = 0

        # ── Warmup buffer (WARMUP_MODE için) ──
        self.warmup_buffer: List[dict] = []
        self.flushing: bool = False
        
        # ── Signal quality logging ──
        self.signal_buffer: List[dict] = []
        self.signal_buffer_limit: int = 1000
        self.signals_path = os.path.join(self.data_lake_path, "signals")
        os.makedirs(self.signals_path, exist_ok=True)

        logger.info("AlphaStrategy INIT: Trend Following (EMA+RSI) modu.")

    # ──────────────────────────────────────────────────────
    # warmup — REST'ten gelen geçmiş mumları yükle
    # ──────────────────────────────────────────────────────
    def warmup(self, closes: list, volumes: list,
               highs: list | None = None, lows: list | None = None):
        """Bot başlarken REST /fapi/v1/klines'tan çekilen geçmiş verileri yükler."""
        for i, c in enumerate(closes):
            self.closes.append(float(c))
            self.volumes.append(float(volumes[i]))
            if highs:
                self.highs.append(float(highs[i]))
            else:
                self.highs.append(float(c))
            if lows:
                self.lows.append(float(lows[i]))
            else:
                self.lows.append(float(c))

        # EMA'ları başlat (geçmiş veri üzerinden sıralı hesapla)
        if len(self.closes) >= EMA_LONG:
            self._bootstrap_emas()
            self._last_rsi = self._calc_rsi()
            self.kline_ready = True
            logger.info(
                f"Warmup tamamlandi, {len(self.closes)} mum yuklendi. "
                f"EMA{EMA_SHORT}={self._ema_short:.2f} | "
                f"EMA{EMA_LONG}={self._ema_long:.2f} | "
                f"RSI={self._last_rsi:.1f}"
            )
        else:
            logger.warning(
                f"Warmup: {len(self.closes)} mum yuklendi ama "
                f"EMA{EMA_LONG} icin yetersiz. WebSocket verisini bekliyoruz."
            )

    def _bootstrap_emas(self):
        """Geçmiş fiyat listesinden EMA zincirini sıfırdan hesaplar."""
        prices = list(self.closes)
        # EMA Short
        k_s = 2.0 / (EMA_SHORT + 1)
        ema_s = prices[0]
        for p in prices[1:]:
            ema_s = p * k_s + ema_s * (1.0 - k_s)
        self._ema_short = ema_s
        self._prev_ema_short = ema_s

        # EMA Long
        k_l = 2.0 / (EMA_LONG + 1)
        ema_l = prices[0]
        for p in prices[1:]:
            ema_l = p * k_l + ema_l * (1.0 - k_l)
        self._ema_long = ema_l
        self._prev_ema_long = ema_l

    # ──────────────────────────────────────────────────────
    # _calc_ema  —  Saf Python EMA (Pandas/Numpy yok)
    # ──────────────────────────────────────────────────────
    def _calc_ema(self, period: int) -> float:
        """Son closes üzerinden standart EMA hesaplar.
        NOT: Bu metod yalnızca tek seferlik (bootstrap) hesaplamada kullanılır.
        Canlıda _update_emas() incremental güncelleme yapar."""
        prices = list(self.closes)
        if len(prices) < period:
            return prices[-1] if prices else 0.0
        k = 2.0 / (period + 1)
        ema = prices[0]
        for p in prices[1:]:
            ema = p * k + ema * (1.0 - k)
        return ema

    def _update_emas(self, new_close: float):
        """Incremental O(1) EMA güncellemesi — her yeni kapanışta çağrılır."""
        self._prev_ema_short = self._ema_short
        self._prev_ema_long = self._ema_long

        k_s = 2.0 / (EMA_SHORT + 1)
        self._ema_short = new_close * k_s + self._ema_short * (1.0 - k_s)

        k_l = 2.0 / (EMA_LONG + 1)
        self._ema_long = new_close * k_l + self._ema_long * (1.0 - k_l)

    # ──────────────────────────────────────────────────────
    # _calc_rsi  —  Saf Python RSI (Wilder's Smoothing)
    # ──────────────────────────────────────────────────────
    def _calc_rsi(self) -> float:
        """Son RSI_PERIOD mumun average gain/loss üzerinden RSI hesaplar."""
        prices = list(self.closes)
        if len(prices) < RSI_PERIOD + 1:
            return 50.0  # Yetersiz veri → nötr

        changes = [prices[i] - prices[i - 1] for i in range(1, len(prices))]
        # Son RSI_PERIOD değişikliği al
        recent = changes[-(RSI_PERIOD):]

        gains = [c for c in recent if c > 0]
        losses = [-c for c in recent if c < 0]

        avg_gain = sum(gains) / RSI_PERIOD if gains else 0.0
        avg_loss = sum(losses) / RSI_PERIOD if losses else 0.0

        if avg_loss == 0:
            return 100.0
        rs = avg_gain / avg_loss
        return 100.0 - (100.0 / (1.0 + rs))

    # ──────────────────────────────────────────────────────
    # _calc_adx  —  Saf Python ADX (Wilder's Smoothing)
    # ──────────────────────────────────────────────────────
    def _calc_adx(self, period: int = 14) -> float:
        """Son mumlardan True Range ve Directional Movement ile ADX hesaplar."""
        highs = list(self.highs)
        lows = list(self.lows)
        closes = list(self.closes)
        n = len(closes)
        
        if n < period * 2:
            return 50.0  # Yetersiz veri -> Nötr (engel olmasın diye yüksek başlat)

        # Raw hesaplamalar
        tr = []
        plus_dm = []
        minus_dm = []
        
        for i in range(1, n):
            h = highs[i]
            l = lows[i]
            prev_c = closes[i-1]
            prev_h = highs[i-1]
            prev_l = lows[i-1]
            
            # True Range
            tr.append(max(h - l, abs(h - prev_c), abs(l - prev_c)))
            
            # Directional Movement
            up_move = h - prev_h
            down_move = prev_l - l
            
            if up_move > down_move and up_move > 0:
                plus_dm.append(up_move)
                minus_dm.append(0.0)
            elif down_move > up_move and down_move > 0:
                plus_dm.append(0.0)
                minus_dm.append(down_move)
            else:
                plus_dm.append(0.0)
                minus_dm.append(0.0)

        # Wilder's Smoothing First Values
        tr_smooth = sum(tr[:period])
        pdm_smooth = sum(plus_dm[:period])
        mdm_smooth = sum(minus_dm[:period])
        
        dx = []
        # DI ve DX hesaplama döngüsü
        for i in range(period, len(tr)):
            tr_smooth = tr_smooth - (tr_smooth / period) + tr[i]
            pdm_smooth = pdm_smooth - (pdm_smooth / period) + plus_dm[i]
            mdm_smooth = mdm_smooth - (mdm_smooth / period) + minus_dm[i]
            
            if tr_smooth == 0:
                pdi = 0.0
                mdi = 0.0
            else:
                pdi = 100 * (pdm_smooth / tr_smooth)
                mdi = 100 * (mdm_smooth / tr_smooth)
            
            if (pdi + mdi) == 0:
                dx.append(0.0)
            else:
                dx.append(100 * abs(pdi - mdi) / (pdi + mdi))

        if len(dx) < period:
            return 50.0

        # ADX Smoothing
        adx = sum(dx[:period]) / period
        for i in range(period, len(dx)):
            adx = ((adx * (period - 1)) + dx[i]) / period
            
        return adx

    # ──────────────────────────────────────────────────────
    # process_kline  —  Her kapanan 1m mumda çağrılır
    # ──────────────────────────────────────────────────────
    async def process_kline(self, k_data: dict):
        """WebSocket'ten gelen kline verisini işler.
        k_data Binance formatında: {'t', 'o', 'h', 'l', 'c', 'v', 'x', ...}
        """
        # Mum henüz kapanmadıysa atla
        if not k_data.get("x", False):
            return

        close = float(k_data["c"])
        high = float(k_data["h"])
        low = float(k_data["l"])
        volume = float(k_data["v"])

        self.closes.append(close)
        self.highs.append(high)
        self.lows.append(low)
        self.volumes.append(volume)

        # Warmup kontrolü
        if not self.kline_ready:
            if len(self.closes) >= EMA_LONG:
                self._bootstrap_emas()
                self._last_rsi = self._calc_rsi()
                self._last_adx = self._calc_adx()
                self.kline_ready = True
                logger.info(
                    f"Warmup tamamlandi (WebSocket), {len(self.closes)} mum. "
                    f"EMA{EMA_SHORT}={self._ema_short:.2f} | "
                    f"EMA{EMA_LONG}={self._ema_long:.2f} | ADX={self._last_adx:.1f}"
                )
            return

        # ── İndikatörleri güncelle ──
        self._update_emas(close)
        rsi = self._calc_rsi()
        self._last_rsi = rsi
        
        adx = self._calc_adx()
        self._last_adx = adx

        # ── Hacim Filtresi ──
        from core.config import VOLUME_MULTIPLIER
        vol_list = list(self.volumes)
        if len(vol_list) >= 20:
            vol_sma20 = sum(vol_list[-20:]) / 20.0
        else:
            vol_sma20 = sum(vol_list) / len(vol_list) if vol_list else 1.0
        volume_ok = volume > vol_sma20 * VOLUME_MULTIPLIER

        # ── Crossover Tespiti ──
        cross_up = (self._prev_ema_short <= self._prev_ema_long and
                    self._ema_short > self._ema_long)
        cross_down = (self._prev_ema_short >= self._prev_ema_long and
                      self._ema_short < self._ema_long)

        bullish_trend = self._ema_short > self._ema_long
        bearish_trend = self._ema_short < self._ema_long

        # ── Sinyal Üretimi ──
        signal = "NONE"

        if adx > 25.0:
            if bullish_trend and rsi > RSI_BUY_MIN and volume_ok:
                signal = "BUY"
            elif bearish_trend and rsi < RSI_SELL_MAX and volume_ok:
                signal = "SELL"

        self._last_signal = signal

        # Log
        cross_tag = ""
        if cross_up:
            cross_tag = " [CROSS UP]"
        elif cross_down:
            cross_tag = " [CROSS DOWN]"

        logger.info(
            f"KLINE KAPANDI: Close={close:.2f} | "
            f"EMA{EMA_SHORT}={self._ema_short:.2f} | "
            f"EMA{EMA_LONG}={self._ema_long:.2f} | "
            f"RSI={rsi:.1f} | ADX={adx:.1f} | "
            f"Vol={volume:.1f} (SMA20={vol_sma20:.1f}) | "
            f"Sinyal={signal}{cross_tag}"
        )

        # ── Sinyal Kalitesi Loglama ──
        if signal in ("BUY", "SELL"):
            signal_record = {
                "timestamp": int(time.time() * 1000),
                "signal": signal,
                "ema_short": float(self._ema_short),
                "ema_long": float(self._ema_long),
                "rsi": float(rsi),
                "adx": float(adx),
                "volume_ratio": float(volume / vol_sma20) if vol_sma20 > 0 else 1.0,
                "close_price": float(close),
                "would_have_result": None
            }
            self.signal_buffer.append(signal_record)
            if len(self.signal_buffer) >= self.signal_buffer_limit:
                asyncio.create_task(self._flush_signals())

        # ── Sinyal varsa işleme gir ──
        if signal != "NONE":
            await self._execute_entry_signal(signal, close)

    # ──────────────────────────────────────────────────────
    # _execute_entry_signal  —  Güvenlik kapılarından geçir ve emir ver
    # ──────────────────────────────────────────────────────
    async def _execute_entry_signal(self, signal: str, price: float):
        now = time.time()

        # ── Pause kontrolü ──
        if self.paused:
            return

        # ── Mevcut pozisyon bilgisi ──
        if DRY_RUN:
            pos_amt = self.sim_pos_amt
            entry_price = self.sim_entry_price
            wallet_balance = Decimal("1500.0")
        else:
            pos_amt = getattr(self.engine, "position_amt", Decimal("0"))
            wallet_balance = getattr(self.engine, "wallet_balance", Decimal("100.0"))
            entry_price = getattr(self.engine, "entry_price", Decimal("0"))

        # ── GATE 1: Zaten pozisyon varsa yeni giriş yapma ──
        if pos_amt != Decimal("0"):
            return

        # ── GATE 2: Daily PnL Kill Switch ──
        if now - self.daily_reset_time > 86400:
            self.daily_pnl = Decimal("0")
            self.daily_reset_time = now
            self.consecutive_losses = 0

        daily_loss_limit = -(wallet_balance * DAILY_LOSS_PCT)
        if self.daily_pnl < daily_loss_limit:
            logger.critical(f"DAILY LOSS LIMIT HIT ({self.daily_pnl}). Yeni islem engellendi.")
            return

        # ── GATE 3: Post-Exit Cooldown ──
        base_cooldown = COOLDOWN_AFTER_LOSS_SEC
        if self.consecutive_losses >= 2:
            base_cooldown = 900
        if now - self.last_exit_time < base_cooldown:
            return

        # ── GATE 4: Circuit Breaker ──
        if getattr(self.engine, "toxic_flow_active", False):
            return

        # ── GATE 5: Funding Rate ──
        if self.funding_monitor and not self.funding_monitor.is_entry_safe(signal):
            logger.warning(f"Funding rate uygun degil, {signal} sinyali engellendi.")
            return

        # ── Kelly Position Sizing ──
        ask = self.lob.get_best_ask()
        q = self.kelly.calculate_trade_size(wallet_balance, ask if ask > 0 else Decimal(str(price)))
        if q < Decimal("0.001"):
            q = Decimal("0.001")
        remaining = MAX_POSITION_BTC - abs(pos_amt)
        if remaining <= Decimal("0"):
            return
        q = min(q, remaining)

        if q < Decimal("0.001"):
            return

        # ── EMİR VER ──
        target_price = Decimal(str(price))
        if DRY_RUN:
            logger.critical(
                f"[DRY_RUN EMIR]: {signal} sinyali tetiklendi! "
                f"Fiyat={price:.2f} | Kelly={q} lot | "
                f"EMA{EMA_SHORT}={self._ema_short:.2f} | "
                f"EMA{EMA_LONG}={self._ema_long:.2f} | "
                f"RSI={self._last_rsi:.1f}"
            )
            self._sim_enter_trade(signal, target_price, q)
        else:
            symbol = self.lob.symbol
            if signal == "BUY":
                bid = self.lob.get_best_bid()
                await self.engine.place_strict_maker(symbol, "BUY", Decimal(str(bid)), q, lob=self.lob)
            else:
                ask_p = self.lob.get_best_ask()
                await self.engine.place_strict_maker(symbol, "SELL", Decimal(str(ask_p)), q, lob=self.lob)

        self.position_open_time = now

    # ──────────────────────────────────────────────────────
    # check_exit_conditions  —  Her LOB tick'inde çağrılır
    # ──────────────────────────────────────────────────────
    async def check_exit_conditions(self, current_price: float):
        """LOB tick bazında sürekli pozisyon izler, TP/SL/Trend dönüşü kontrol eder."""
        now = time.time()

        if DRY_RUN:
            pos_amt = self.sim_pos_amt
            entry_price = self.sim_entry_price
            wallet_balance = Decimal("1500.0")
        else:
            pos_amt = getattr(self.engine, "position_amt", Decimal("0"))
            entry_price = getattr(self.engine, "entry_price", Decimal("0"))
            wallet_balance = getattr(self.engine, "wallet_balance", Decimal("100.0"))

        if pos_amt == Decimal("0") or entry_price <= Decimal("0"):
            return

        cp = Decimal(str(current_price))
        is_long = pos_amt > Decimal("0")

        # ── PnL Hesaplama ──
        if is_long:
            pnl_pct = float((cp - entry_price) / entry_price)
        else:
            pnl_pct = float((entry_price - cp) / entry_price)

        exit_reason = None

        # ── CHECK 1: Take Profit (%0.8) ──
        if pnl_pct >= TAKE_PROFIT_PCT:
            exit_reason = "TAKE_PROFIT"

        # ── CHECK 2: Stop Loss (%0.4) ──
        elif pnl_pct <= -STOP_LOSS_PCT:
            exit_reason = "STOP_LOSS"

        # ── CHECK 3: Trend Dönüşü (EMA Cross tersine döndü) ──
        elif self.kline_ready:
            if is_long and self._ema_short < self._ema_long:
                exit_reason = "TREND_REVERSAL"
            elif not is_long and self._ema_short > self._ema_long:
                exit_reason = "TREND_REVERSAL"

        # ── CHECK 4: Funding saatine 10 dakika kala ──
        if exit_reason is None and self.funding_monitor:
            try:
                next_funding = getattr(self.funding_monitor, "next_funding_time", 0)
                if next_funding > 0 and (next_funding - now) < 600:
                    exit_reason = "FUNDING_PROXIMITY"
            except Exception:
                pass

        # ── CHECK 5: Max Hold Süresi ──
        if exit_reason is None and self.position_open_time > 0:
            if now - self.position_open_time > MAX_POSITION_HOLD_SECONDS:
                exit_reason = "TIME_LOCK"

        # ── CHECK 6: Hard Drawdown Emergency (%15) ──
        if exit_reason is None:
            unrealized = Decimal(str(pnl_pct)) * wallet_balance
            mdd_threshold = -(wallet_balance * MDD_HARD_STOP_PCT)
            if unrealized < mdd_threshold:
                exit_reason = "EMERGENCY_MDD"

        # ── ÇIKIŞ ──
        if exit_reason:
            exit_side = "SELL" if is_long else "BUY"
            logger.critical(
                f"EXIT [{exit_reason}]: PnL={pnl_pct*100:+.3f}% | "
                f"Entry={entry_price} | Now={current_price:.2f} | "
                f"Side={exit_side}"
            )

            if DRY_RUN:
                await self._sim_exit_trade(
                    exit_reason,
                    Decimal(str(self.lob.get_best_bid())) if is_long
                    else Decimal(str(self.lob.get_best_ask()))
                )
            else:
                symbol = self.lob.symbol
                await self.engine.emergency_market_exit(symbol, abs(pos_amt), exit_side)

            # Risk state güncelle
            self.last_exit_time = now
            self.peak_pnl = Decimal("0")
            self.position_open_time = 0.0

            # Win/Loss tracking
            if pnl_pct > 0:
                self.consecutive_losses = 0
                self.trade_history.append(1.0)
            else:
                self.consecutive_losses += 1
                self.trade_history.append(0.0)
            self.daily_pnl += Decimal(str(pnl_pct)) * wallet_balance
            self.kelly.record_trade_result(pnl_pct)

    # ──────────────────────────────────────────────────────
    # evaluate_market  —  Eski API uyumluluğu (main.py signal_watcher)
    # ──────────────────────────────────────────────────────
    async def evaluate_market(self):
        """Eski brain_process signal_watcher'dan çağrılıyor.
        Artık sadece LOB fiyatını alıp check_exit_conditions'a yönlendirir."""
        bb = self.lob.get_best_bid()
        ba = self.lob.get_best_ask()
        if bb <= 0 or ba <= 0:
            return

        self.tick_count += 1

        mid = float((bb + ba) / 2.0)

        # Telemetri logu (her 500 tick'te bir)
        if self.tick_count % 500 == 0:
            logger.info(
                f"LOB TELEMETRY [Tick {self.tick_count}]: "
                f"Mid={mid:.2f} | EMA{EMA_SHORT}={self._ema_short:.2f} | "
                f"EMA{EMA_LONG}={self._ema_long:.2f} | RSI={self._last_rsi:.1f} | "
                f"Sinyal={self._last_signal}"
            )

        # Her tick'te TP/SL kontrolü
        await self.check_exit_conditions(mid)

        # WARMUP_MODE: Veri toplama (varsa)
        if WARMUP_MODE:
            now = time.time()
            row = {
                "timestamp": now,
                "mid_price": mid,
                "best_bid": bb,
                "best_ask": ba,
            }
            self.warmup_buffer.append(row)
            if not hasattr(self, 'last_flush_time'):
                self.last_flush_time = now
            if len(self.warmup_buffer) >= 5000 and not self.flushing:
                self.flushing = True
                asyncio.create_task(self._flush_data_lake())

    # ──────────────────────────────────────────────────────
    # update_signal  —  Eski API uyumluluğu
    # ──────────────────────────────────────────────────────
    def update_signal(self, key: str, value: float):
        """brain_process'ten gelen sinyalleri alır. Yeni stratejide
        artık Z-Score/VPIN/OBI kullanılmıyor ama main.py bozulmasın."""
        pass

    # ──────────────────────────────────────────────────────
    # DRY_RUN Simülasyon Yardımcıları
    # ──────────────────────────────────────────────────────
    def _sim_enter_trade(self, side: str, target: Decimal, q: Decimal):
        self.sim_side = side
        self.sim_qty = q

        # LOB VWAP slippage
        vwap_price = self.lob.simulate_market_order(side, float(q))
        self.sim_entry_price = Decimal(str(vwap_price))
        self.sim_pos_amt = q if side == "BUY" else -q

        logger.info(
            f"[SIM] POZISYON ACILDI: {side} {q} @ {vwap_price:.2f} (LOB VWAP)"
        )

    async def _sim_exit_trade(self, reason: str, fallback_exit_price: Decimal):
        if self.sim_pos_amt == Decimal("0"):
            return

        exit_side = "SELL" if self.sim_pos_amt > Decimal("0") else "BUY"
        vwap_exit = self.lob.simulate_market_order(exit_side, float(abs(self.sim_pos_amt)))
        exit_price = Decimal(str(vwap_exit))

        if self.sim_pos_amt > Decimal("0"):
            gross_pnl = float((exit_price - self.sim_entry_price) * self.sim_qty)
        else:
            gross_pnl = float((self.sim_entry_price - exit_price) * self.sim_qty)

        fee = float(self.sim_entry_price * self.sim_qty + exit_price * self.sim_qty) * 0.0005
        net_pnl = gross_pnl - fee

        if self.reporter:
            await self.reporter.log_trade({
                "timestamp": time.time(),
                "symbol": self.lob.symbol,
                "side": self.sim_side,
                "entry_price": float(self.sim_entry_price),
                "exit_price": float(exit_price),
                "qty": float(self.sim_qty),
                "gross_pnl": gross_pnl,
                "fee": fee,
                "net_pnl": net_pnl,
                "slippage": abs(float(exit_price) - float(fallback_exit_price)),
                "exit_reason": reason,
            })

        logger.info(f"[SIM] POZISYON KAPANDI ({reason}): NET PNL = ${net_pnl:.4f}")
        self.sim_pos_amt = Decimal("0")
        self.sim_entry_price = Decimal("0")

    # ──────────────────────────────────────────────────────
    # forced_flush_daemon  —  Korunuyor (Data Lake)
    # ──────────────────────────────────────────────────────
    async def forced_flush_daemon(self):
        """60 saniyelik zorunlu döküm ve state persistence daemon'u."""
        import aiofiles
        import json
        warmup_file = os.path.join(self.data_lake_path, "warmup_state.json")
        while True:
            await asyncio.sleep(60)
            try:
                warmups = {}
                if os.path.exists(warmup_file):
                    try:
                        async with aiofiles.open(warmup_file, "r") as f:
                            content = await f.read()
                            if content.strip():
                                warmups = json.loads(content)
                    except Exception:
                        pass
                warmups[self.lob.symbol] = self.tick_count
                async with aiofiles.open(warmup_file, "w") as f:
                    await f.write(json.dumps(warmups))

                if hasattr(self, 'warmup_buffer') and len(self.warmup_buffer) > 0 and not self.flushing:
                    self.flushing = True
                    asyncio.create_task(self._flush_data_lake())
            except Exception as e:
                logger.error(f"Forced Flush Daemon Fault: {e}")

    async def _flush_data_lake(self):
        try:
            import pandas as pd
            buffer_copy = self.warmup_buffer.copy()
            self.warmup_buffer.clear()
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._write_parquet, buffer_copy)
        except Exception as e:
            logger.error(f"Data Lake flush dispatch failed: {e}")
        finally:
            self.flushing = False

    def _write_parquet(self, buffer_copy: list):
        import traceback
        try:
            import pandas as pd
            df = pd.DataFrame(buffer_copy)
            filename = f"{self.data_lake_path}/balina_kline_{int(time.time())}.parquet"
            df.to_parquet(filename, engine="pyarrow")
            logger.info(f"Flushed {len(buffer_copy)} ticks to Data Lake: {filename}")
        except Exception as e:
            err_msg = traceback.format_exc()
            logger.critical(f"DATA LAKE WRITE ERROR: {err_msg}")

    async def _flush_signals(self):
        if not self.signal_buffer:
            return
        buffer_copy = self.signal_buffer.copy()
        self.signal_buffer.clear()
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._write_signals_parquet, buffer_copy)
        
    def _write_signals_parquet(self, buffer_copy: list):
        import traceback
        try:
            import pandas as pd
            df = pd.DataFrame(buffer_copy)
            filename = os.path.join(self.signals_path, f"signals_{int(time.time())}.parquet")
            df.to_parquet(filename, engine="pyarrow")
            logger.info(f"Flushed {len(buffer_copy)} signals to Data Lake: {filename}")
        except Exception as e:
            err_msg = traceback.format_exc()
            logger.critical(f"SIGNAL LOG WRITE ERROR: {err_msg}")
