git init
echo "venv/" > .gitignore
echo "__pycache__/" >> .gitignore
echo ".env" >> .gitignore
echo "*.key" >> .gitignore
echo "logs/" >> .gitignore
git add .
git commit -m "Initial Balina-Bot HFT commit with complete structure"
