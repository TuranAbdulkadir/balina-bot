import psutil
import shutil
import glob
import os

total, used, free = shutil.disk_usage("/")
free_gb = free / (2**30)
ram_pct = psutil.virtual_memory().percent

files = glob.glob("core/data_lake/*.parquet")
estimated_rows = len(files) * 50000

lock_file = "core/data_lake/SHUTDOWN_LOCK.txt"
lock_status = "AKTIF (SISTEM KILITLI)" if os.path.exists(lock_file) else "PASIF (TEMIZ)"

print("========================================")
print("[24 SAATLIK STABILITE RAPORU (CANLI)]")
print("========================================")
print(f"Kalan Disk Alani  : {free_gb:.2f} GB")
print(f"RAM Kullanimi     : %{ram_pct:.1f}")
print(f"Son 1 Saatte Veri : ~{estimated_rows:,} Satir (Multi-Pair WebSocket)")
print(f"SHUTDOWN_LOCK     : {lock_status}")

import json
warmup_file = "core/data_lake/warmup_state.json"
if os.path.exists(warmup_file):
    try:
        with open(warmup_file, "r") as f:
            warmups = json.load(f)
        print("WARMUP (ISINMA) DURUMLARI:")
        for sym, ticks in warmups.items():
            if ticks >= 3000:
                print(f"   [{sym}: {ticks}/3000 Tick - PUSUDA READY]")
            else:
                print(f"   [{sym}: {ticks}/3000 Tick - ISINIYOR]")
    except Exception:
        pass

print("========================================")
