﻿import asyncio
import time
import os
from decimal import Decimal, ROUND_DOWN
from typing import Dict, List
from core.logger_factory import get_logger
from core.config import WARMUP_MODE
from core.mathematics import FeeMath
from core.kelly_manager import KellyRiskManager
import pandas as pd

logger = get_logger("StrategyAlpha")

# ═══════════════════════════════════════════════════════════
# Phase 28: IRON CONSTANTS — Absolute Hard Limits
# ═══════════════════════════════════════════════════════════
MAX_POSITION_BTC = Decimal("0.050")       # MAX KÂR MODU: İşlem kapasitesi 50 KAT artırıldı (0.001 -> 0.050)
DAILY_LOSS_PCT = Decimal("0.02")          # Kill switch: Günlük en fazla %2 kayıp
TRAILING_STOP_TRIGGER = Decimal("0.05")   # Minimum profit ($): 5 CENT
TRAILING_STOP_PCT = Decimal("0.10")       # Lock profit: Kar dondugunde saniyesinde sat
MDD_HARD_STOP_PCT = Decimal("0.01")       # FATAL FIX: Her islemde %1 mutlak max zararda acil cikis! (Eski 0.15)
BLACK_SWAN_Z = 3.5                        # Z-Score breakout threshold for panic exit
MAX_SPREAD_BPS = 5.0                      # Refuse to trade if spread > 0.5 ticks
COOLDOWN_AFTER_LOSS_SEC = 30.0            # Wait 30s after any emergency exit

class AlphaStrategy:
    def __init__(self, engine, lob):
        self.engine = engine
        self.lob = lob
        self.data_lake_path = "core/data_lake"
        self.warmup_buffer: List[dict] = []
        self.latest_signals = {"vpin": 0.0, "zscore": 0.0, "obi": 0.0}
        self.ema_obi = 0.0
        # MAX KÂR: Kaldıraç 20X yapıldı. Sermayenin %50'si ile çok agresif pozisyon büyüklüğü.
        self.kelly = KellyRiskManager(kelly_fraction="0.50", max_leverage="20.0")
        self.tick_count = 0
        self.flushing = False
        
        # Phase 28: Risk State Trackers
        self.peak_pnl = Decimal("0")          # Trailing stop: highest unrealized PnL
        self.daily_pnl = Decimal("0")         # Daily cumulative realized PnL
        self.daily_reset_time = time.time()   # Daily PnL counter reset anchor
        self.last_exit_time = 0.0             # Cooldown timer after emergency exits
        self.consecutive_losses = 0           # Escalating cooldown on losing streaks
        
        # Phase 20: Win-rate tracker
        from collections import deque
        self.trade_history = deque(maxlen=50)
        self.last_pos_amt = Decimal("0")
        self.last_upnl = Decimal("0")
        self.last_entry_price = Decimal("0")
        
        if WARMUP_MODE:
            os.makedirs(self.data_lake_path, exist_ok=True)
            logger.critical("🤖 WARM-UP ENGAGED. Live Validation Active.")
    
    def update_signal(self, key: str, value: float):
        self.latest_signals[key] = value
            
    async def evaluate_market(self):
        now = time.time()
        zscore = self.latest_signals["zscore"]
        vpin = self.latest_signals["vpin"]
        obi = self.latest_signals["obi"]
        
        # OBI Momentum Velocity (Delta-OBI)
        if self.tick_count == 0 and self.ema_obi == 0.0:
            self.ema_obi = obi
            
        ema_alpha = 0.20
        self.ema_obi = (ema_alpha * obi) + ((1.0 - ema_alpha) * self.ema_obi)
        delta_obi = obi - self.ema_obi
        
        bb = self.lob.get_best_bid()
        ba = self.lob.get_best_ask()
        
        if bb <= 0.0 or ba <= 0.0:
            return

        from api.health import state
        if not WARMUP_MODE and state.latency_ms > 1000.0:
            if self.tick_count % 15 == 0:
                logger.warning(f"GHOST BOOK RISK! Latency {state.latency_ms:.0f}ms. Halting.")
            return

        # ═══════════════════════════════════════════════════
        # WARMUP MODE: Data Collection Only
        # ═══════════════════════════════════════════════════
        if WARMUP_MODE:
            self.warmup_buffer.append({
                "timestamp": now,
                "zscore": zscore,
                "vpin": vpin,
                "obi": obi,
                "best_bid": bb,
                "best_ask": ba
            })
            
            self.tick_count += 1
            if self.tick_count % 150 == 0:
                logger.info(f"📊 LIVE TELEMETRY [Tick {self.tick_count}]: Z-Score: {zscore:.3f} | VPIN: {vpin:.3f} | OBI: {obi:.3f} | LOB Spreads: {bb} / {ba}")
                
            if len(self.warmup_buffer) >= 5000 and not self.flushing:
                self.flushing = True
                asyncio.create_task(self._flush_data_lake())
            return

        # ═══════════════════════════════════════════════════
        # LIVE ALPHA: Phase 28 Iron-Clad Risk Gauntlet
        # Every trade must survive ALL checks below.
        # ═══════════════════════════════════════════════════

        pos_amt = getattr(self.engine, "position_amt", Decimal("0"))
        wallet_balance = getattr(self.engine, "wallet_balance", Decimal("100.0"))
        unrealized_pnl = getattr(self.engine, "unrealized_pnl", Decimal("0"))
        entry_price = getattr(self.engine, "entry_price", Decimal("0"))

        # ── GATE 1: Daily PnL Kill Switch ──
        if now - self.daily_reset_time > 86400:
            self.daily_pnl = Decimal("0")
            self.daily_reset_time = now
            self.consecutive_losses = 0
            logger.info("📅 Daily PnL counter reset.")

        daily_loss_limit = -(wallet_balance * DAILY_LOSS_PCT)
        if self.daily_pnl < daily_loss_limit:
            if self.tick_count % 100 == 0:
                logger.critical(f"🛑 DAILY LOSS LIMIT HIT: {self.daily_pnl}. ALL TRADING SUSPENDED until reset.")
            # BUG FIX: Eger iceride pozisyon kalmissa sistemi dondurmak yerine acil cikis yap!
            if pos_amt != Decimal("0"):
                logger.critical("🛑 GÜNLÜK ZARAR LİMİTİ AŞILDI! AÇIK POZİSYON ACİL OLARAK KAPATILIYOR!")
                exit_side = "SELL" if pos_amt > Decimal("0") else "BUY"
                await self.engine.emergency_market_exit("BTCUSDT", abs(pos_amt), exit_side)
                self.last_exit_time = now
            return

        # ── GATE 2: Post-Exit Cooldown ──
        cooldown = COOLDOWN_AFTER_LOSS_SEC * (1 + self.consecutive_losses)
        if now - self.last_exit_time < cooldown and pos_amt == Decimal("0"):
            return

        # ── GATE 3: VPIN Toxic Flow Shield ──
        if vpin > 0.8:
            if not self.engine.toxic_flow_active:
                logger.warning("TOXIC FLOW DETECTED! Pulling passive Maker orders.")
            self.engine.toxic_flow_active = True
        else:
            self.engine.toxic_flow_active = False

        # ── GATE 4: Win-Rate Tracker (Realized PnL Recording) ──
        if self.last_pos_amt != Decimal("0") and pos_amt == Decimal("0"):
            # Position just closed
            realized = self.last_upnl  # Approximate realized from last unrealized
            self.trade_history.append(1.0 if self.last_upnl > Decimal("0") else 0.0)
            self.kelly.record_trade_result(float(self.last_upnl))
            self.daily_pnl += self.last_upnl
            
            if self.last_upnl <= Decimal("0"):
                self.consecutive_losses += 1
            else:
                self.consecutive_losses = 0
                
            logger.info(f"📊 TRADE CLOSED: PnL={self.last_upnl}, Daily={self.daily_pnl}, Streak={'W' if self.last_upnl > 0 else 'L'}{self.consecutive_losses}")

        self.last_pos_amt = pos_amt
        self.last_upnl = unrealized_pnl
        if entry_price > Decimal("0"):
            self.last_entry_price = entry_price

        # ── GATE 5: Hard Drawdown Emergency Exit (15% equity) ──
        mdd_threshold = -(wallet_balance * MDD_HARD_STOP_PCT)
        if pos_amt != Decimal("0") and unrealized_pnl < mdd_threshold:
            logger.critical(f"🔴 FATAL DRAWDOWN: {unrealized_pnl} USDT. EMERGENCY MARKET EXIT!")
            exit_side = "SELL" if pos_amt > Decimal("0") else "BUY"
            await self.engine.emergency_market_exit("BTCUSDT", abs(pos_amt), exit_side)
            self.last_exit_time = now
            self.peak_pnl = Decimal("0")
            return

        # ── GATE 6: Black Swan Z-Score Panic Exit ──
        if pos_amt > Decimal("0") and zscore < -BLACK_SWAN_Z:
            logger.critical(f"⚫ BLACK SWAN WICK! Z={zscore:.2f}. Emergency Exit Long!")
            await self.engine.emergency_market_exit("BTCUSDT", abs(pos_amt), "SELL")
            self.last_exit_time = now
            self.peak_pnl = Decimal("0")
            return
            
        if pos_amt < Decimal("0") and zscore > BLACK_SWAN_Z:
            logger.critical(f"⚫ BLACK SWAN SQUEEZE! Z={zscore:.2f}. Emergency Exit Short!")
            await self.engine.emergency_market_exit("BTCUSDT", abs(pos_amt), "BUY")
            self.last_exit_time = now
            self.peak_pnl = Decimal("0")
            return

        # ── GATE 7: Trailing Stop-Loss (REMOVED FOR GRID PURITY) ──
        # In a Pure Maker grid, TP orders sit rigidly on the book. 
        # Dynamic trailing orders collide with static TP limits (Error -2022 ReduceOnly).
        self.peak_pnl = Decimal("0")

        # ── GATE 8: Spread Width Filter (RELAXED FOR VOLUME) ──
        spread_bps = ((ba - bb) / bb) * 10000 if bb > 0 else 9999
        if spread_bps > 50.0:
            return

        # ═══════════════════════════════════════════════════
        # ALL GATES PASSED: Execute Alpha Logic
        # ═══════════════════════════════════════════════════

        # Kelly Position Sizing
        q = self.kelly.calculate_trade_size(wallet_balance, ba)
        if q < Decimal("0.001"):
            q = Decimal("0.001")
        remaining_capacity = MAX_POSITION_BTC - abs(pos_amt)
        if remaining_capacity <= Decimal("0"):
            q = Decimal("0")
        else:
            q = min(q, remaining_capacity)

        if q < Decimal("0.001"):
            pass

        # Phase 87: PURE GRID MAKER OVERRIDE (State & Temporal Aware)
        # Prevents infinite Margin-Exceeding Limit Spam
        now_ts = time.time()
        if not hasattr(self, 'last_entry_time'):
            self.last_entry_time = 0
            
        # Evaluate dynamic configuration
        import json
        dynamic_z_threshold = 1.0  # YAPAY ZEKA ONAYLI KUSURSUZ GİRİŞ: Z-Score 1.0
        tp_target_spread = Decimal("15.0")  # Stabilizasyon için spread hafif genişletildi
        try:
            with open("dynamic_config.json", "r") as f:
                dconf = json.load(f)
                dynamic_z_threshold = float(dconf.get("dynamic_z_threshold", 0.05))
                tp_target_spread = Decimal(str(dconf.get("tp_target", 25.0)))
        except:
            pass

        if not self.engine.toxic_flow_active and q >= Decimal("0.001"):
            # Only allow 1 entry attempt every 2.0 seconds
            if pos_amt == Decimal("0") and (now_ts - self.last_entry_time > 2.0):
                # YAPAY ZEKA ONAYLI GİRİŞ KONTROLLERİ (Z-Score > 1.0 AND OBI > 0.5) 
                if zscore > dynamic_z_threshold and obi < -0.5:
                    target = Decimal(str(ba))
                    self.last_entry_time = now_ts
                    await self.engine.place_strict_maker("BTCUSDT", "SELL", target, q)
            
                elif zscore < -dynamic_z_threshold and obi > 0.5:
                    target = Decimal(str(bb))
                    self.last_entry_time = now_ts
                    await self.engine.place_strict_maker("BTCUSDT", "BUY", target, q)

        # Phase 87 Take Profit: State-Aware Limit Anchor
        if pos_amt != Decimal("0") and entry_price > Decimal("0"):
            if not hasattr(self, 'tp_placed_for_entry'):
                self.tp_placed_for_entry = Decimal("0")
                
            # Floating point comparison is safe here since entry_price is fixed by Binance
            if self.tp_placed_for_entry != entry_price:
                if pos_amt > Decimal("0"):
                    # Long Position -> Sell Limit above entry
                    tp_target = entry_price + tp_target_spread
                    logger.info(f"💰 GRID PROFIT LOCK: Anchoring TP Maker ASK: {entry_price} -> {tp_target} (Dynamic Spread: ${tp_target_spread})")
                    await self.engine.place_strict_maker("BTCUSDT", "SELL", tp_target, abs(pos_amt), reduce_only=True)
                    self.tp_placed_for_entry = entry_price
                    
                elif pos_amt < Decimal("0"):
                    # Short Position -> Buy Limit below entry
                    tp_target = entry_price - tp_target_spread
                    logger.info(f"💰 GRID PROFIT LOCK: Anchoring TP Maker BID: {entry_price} -> {tp_target} (Dynamic Spread: ${tp_target_spread})")
                    await self.engine.place_strict_maker("BTCUSDT", "BUY", tp_target, abs(pos_amt), reduce_only=True)
                    self.tp_placed_for_entry = entry_price

    async def _flush_data_lake(self):
        try:
            buffer_copy = self.warmup_buffer.copy()
            self.warmup_buffer.clear()
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._write_parquet, buffer_copy)
        except Exception as e:
            logger.error(f"Data Lake flush dispatch failed: {e}")
        finally:
            self.flushing = False

    def _write_parquet(self, buffer_copy: list):
        try:
            df = pd.DataFrame(buffer_copy)
            filename = f"{self.data_lake_path}/balina_warmup_{int(time.time())}.parquet"
            df.to_parquet(filename, engine="pyarrow")
            logger.info(f"💾 Flushed {len(buffer_copy)} LOB ticks to Local Data Lake: {filename}")
        except Exception as e:
            logger.error(f"Data Lake thread execution failed: {e}")
