import asyncio
import sys
import os
sys.path.append('/home/ubuntu/balina_bot')
from dotenv import load_dotenv
load_dotenv('/home/ubuntu/balina_bot/.env')
from core.config import BINANCE_API_KEY, BINANCE_API_SECRET
from network.http_client import BinanceHTTPClient

async def f():
    client = BinanceHTTPClient(BINANCE_API_KEY, BINANCE_API_SECRET)
    print(await client.get_signed('/fapi/v1/positionSide/dual'))
    try:
        print(await client.post_signed('/fapi/v1/positionSide/dual', {'dualSidePosition': 'false'}))
    except Exception as e:
        if '-4059' in str(e):
            print("Already in One-Way mode")
        else:
            print("Error:", e)
    print(await client.get_signed('/fapi/v1/positionSide/dual'))

asyncio.run(f())
