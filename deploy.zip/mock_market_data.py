import asyncio
from core.logger_factory import get_logger
import time
from core.watchdog import watchdog_task
from api.health import run_fastapi, state
from orderbook.lob import LimitOrderBook

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = get_logger("MockDataTest")

SYMBOL = "BTCUSDT"

async def mock_binance_stream(lob_instance: LimitOrderBook):
    """
    Simulates Binance WS Stream:
    - ~10,000 messages / second target
    - Injects a sequence gap to test LOB sync logic
    """
    last_update_id = 1000
    
    # Fake initial snapshot
    snapshot = {
        "lastUpdateId": last_update_id,
        "bids": [[f"90000.0", "1.5"]],
        "asks": [[f"90001.0", "2.0"]]
    }
    lob_instance.process_snapshot(snapshot)
    
    logger.info("Starting mock WS stream (targeting ~10k msgs/sec)...")
    
    event_count = 0
    start_time = time.time()
    
    while True:
        # Generate next continuous ID
        pu = last_update_id
        U = pu + 1
        u = U + 5
        
        # Inject Gap
        if event_count == 25000:
            logger.warning("--- INJECTING SEQUENCE GAP (Artificial Disconnect) ---")
            U += 100
            u += 100
        
        mock_event = {
            "e": "depthUpdate",
            "E": int(time.time() * 1000),
            "s": SYMBOL,
            "U": U,
            "u": u,
            "pu": pu,
            "b": [[str(90000.0 + (event_count % 10)), "1.0"]],
            "a": [[str(90001.0 + (event_count % 10)), "1.0"]]
        }
        
        try:
            lob_instance.process_diff(mock_event)
        except Exception as e:
            logger.error(f"Error in LOB diff processing: {e}")
            
        last_update_id = u
        event_count += 1
        
        # Simulate network latency stats
        state.latency_ms = (time.time() * 1000) - mock_event["E"]
        state.last_update = time.time()
        
        # Yield to event loop in batches to allow watchdog & api to run, 
        # mimicking 10k msg/sec density (500 msg every 0.05s).
        if event_count % 500 == 0:
            await asyncio.sleep(0.05)
            
        if event_count % 10000 == 0:
            elapsed = time.time() - start_time
            logger.info(f"Generated {event_count} messages. Elapsed: {elapsed:.2f}s. Avg rate: {event_count/elapsed:.0f} msg/sec")
            
        if event_count >= 50000:
            logger.info("Mock stream finished.")
            break

async def inject_watchdog_block():
    """Injects a 150ms synchronous block to test watchdog alert."""
    await asyncio.sleep(3.0)  # Wait a bit before injecting
    logger.warning("--- INJECTING 150ms SYNCHRONOUS THREAD BLOCK (Simulating Heavy CPU computation) ---")
    time.sleep(0.15)
    logger.warning("--- BLOCK FINISHED ---")

async def main():
    logger.info("Initializing Mock Environment...")
    lob = LimitOrderBook(SYMBOL)
    
    state.status = "running_mock"
    state.last_update = time.time()
    
    # Start tasks
    wd_task = asyncio.create_task(watchdog_task(tolerance_sec=0.1))
    api_task = asyncio.create_task(run_fastapi())
    mock_task = asyncio.create_task(mock_binance_stream(lob))
    block_task = asyncio.create_task(inject_watchdog_block())
    
    # Wait for mock to finish
    await mock_task
    logger.info("Test completed successfully.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Mock test stopped by user.")
