import asyncio
import sys
import os
import hmac
import hashlib
import time
import urllib.parse
# Parse .env manually
keys = {}
with open('.env') as f:
    for line in f:
        if '=' in line and not line.startswith('#'):
            k, v = line.strip().split('=', 1)
            keys[k] = v.strip('"\'')

import aiohttp

async def binance_request(endpoint, method='GET', params=None):
    if params is None:
        params = {}
    params['timestamp'] = int(time.time() * 1000)
    query_string = urllib.parse.urlencode(params)
    signature = hmac.new(keys['BINANCE_API_SECRET'].encode(), query_string.encode(), hashlib.sha256).hexdigest()
    params['signature'] = signature
    headers = {'X-MBX-APIKEY': keys['BINANCE_API_KEY']}
    url = f"https://fapi.binance.com{endpoint}"
    async with aiohttp.ClientSession() as session:
        if method == 'GET':
            async with session.get(url, params=params, headers=headers) as resp:
                print(await resp.json())
        else:
            async with session.post(url, data=params, headers=headers) as resp:
                print(await resp.text())

async def main():
    await binance_request('/fapi/v1/positionSide/dual')
    await binance_request('/fapi/v1/positionSide/dual', 'POST', {'dualSidePosition': 'false'})
    await binance_request('/fapi/v1/positionSide/dual')

asyncio.run(main())
