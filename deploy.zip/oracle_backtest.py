import sys
import os
import time
import json
sys.path.insert(0, ".")
from analysis.backtest import BacktestEngine
import io
import polars as pl

# Silence stdout
sys.stdout = io.StringIO()

class TimeFilteredBacktest(BacktestEngine):
    def load_data(self):
        files = [f for f in os.listdir(self.data_dir) if f.endswith(".parquet")]
        current_time = time.time()
        recent_files = []
        for f in files:
            filepath = os.path.join(self.data_dir, f)
            mtime = os.path.getmtime(filepath)
            # Filter exactly 36 hours (covering "dünden bu yana")
            if current_time - mtime <= 36 * 3600:
                 recent_files.append(filepath)
                 
        tables = []
        for filepath in recent_files:
            try:
                tables.append(pl.read_parquet(filepath))
            except Exception:
                pass
                
        if tables:
            self.df = pl.concat(tables)
            self.df = self.df.sort("timestamp")
        else:
            self.df = None

try:
    engine = TimeFilteredBacktest("core/data_lake")
    engine.load_data()
    if engine.df is not None and len(engine.df) > 0:
        res = engine.run_simulation(zscore_threshold=3.5, ema_alpha=0.2)
        with open("oracle_sim_result.json", "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2)
    else:
        with open("oracle_sim_result.json", "w") as f:
             json.dump({"error": "No recent data found"}, f)
except Exception as e:
    with open("oracle_sim_result.json", "w") as f:
        json.dump({"error": str(e)}, f)
