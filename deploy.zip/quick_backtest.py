import requests
import pandas as pd
import numpy as np

# AŞAMA 29.2: Strateji Parametreleri (5m Update)
EMA_SHORT = 21
EMA_LONG = 50
RSI_PERIOD = 14
RSI_BUY_MIN = 60
RSI_SELL_MAX = 40
TAKE_PROFIT_PCT = 0.015
STOP_LOSS_PCT = 0.005
VOLUME_MULTIPLIER = 2.0

# Cüzdan Parametreleri
INITIAL_BALANCE = 300.0
LEVERAGE = 2.0
FEE = 0.0004
SLIPPAGE = 0.0001

def calc_ema(series, period):
    return series.ewm(span=period, adjust=False).mean()

def calc_rsi(series, period):
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def calc_adx(high, low, close, period=14):
    df = pd.DataFrame({'high': high, 'low': low, 'close': close})
    df['tr0'] = abs(df['high'] - df['low'])
    df['tr1'] = abs(df['high'] - df['close'].shift())
    df['tr2'] = abs(df['low'] - df['close'].shift())
    df['tr'] = df[['tr0', 'tr1', 'tr2']].max(axis=1)

    df['up_move'] = df['high'] - df['high'].shift()
    df['down_move'] = df['low'].shift() - df['low']

    df['+dm'] = np.where((df['up_move'] > df['down_move']) & (df['up_move'] > 0), df['up_move'], 0)
    df['-dm'] = np.where((df['down_move'] > df['up_move']) & (df['down_move'] > 0), df['down_move'], 0)

    # Wilder's Smoothing
    df['tr_sm'] = df['tr'].ewm(alpha=1/period, adjust=False).mean()
    df['+dm_sm'] = df['+dm'].ewm(alpha=1/period, adjust=False).mean()
    df['-dm_sm'] = df['-dm'].ewm(alpha=1/period, adjust=False).mean()

    df['+di'] = 100 * (df['+dm_sm'] / df['tr_sm'])
    df['-di'] = 100 * (df['-dm_sm'] / df['tr_sm'])
    
    df['dx'] = 100 * abs(df['+di'] - df['-di']) / (df['+di'] + df['-di'])
    df['adx'] = df['dx'].ewm(alpha=1/period, adjust=False).mean()
    
    return df['adx']

def run_backtest():
    url = "https://fapi.binance.com/fapi/v1/klines?symbol=BTCUSDT&interval=5m&limit=1000"
    data = requests.get(url).json()
    
    df = pd.DataFrame(data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'qav', 'num_trades', 'taker_base_vol', 'taker_quote_vol', 'ignore'])
    df['high'] = df['high'].astype(float)
    df['low'] = df['low'].astype(float)
    df['close'] = df['close'].astype(float)
    df['volume'] = df['volume'].astype(float)
    
    df['ema_short'] = calc_ema(df['close'], EMA_SHORT)
    df['ema_long'] = calc_ema(df['close'], EMA_LONG)
    df['rsi'] = calc_rsi(df['close'], RSI_PERIOD)
    df['adx'] = calc_adx(df['high'], df['low'], df['close'], 14)
    df['vol_sma20'] = df['volume'].rolling(window=20).mean()
    
    balance = INITIAL_BALANCE
    pos_type = 0 # 1 long, -1 short, 0 none
    entry_price = 0
    trade_history = []
    equity_curve = [INITIAL_BALANCE]
    
    for i in range(50, len(df)):
        close = df['close'].iloc[i]
        
        # Sinyal Üretimi
        ema_short = df['ema_short'].iloc[i]
        ema_long = df['ema_long'].iloc[i]
        prev_ema_short = df['ema_short'].iloc[i-1]
        prev_ema_long = df['ema_long'].iloc[i-1]
        rsi = df['rsi'].iloc[i]
        adx = df['adx'].iloc[i]
        vol = df['volume'].iloc[i]
        vol_sma20 = df['vol_sma20'].iloc[i]
        
        bullish = ema_short > ema_long
        bearish = ema_short < ema_long
        cross_up = prev_ema_short <= prev_ema_long and ema_short > ema_long
        cross_down = prev_ema_short >= prev_ema_long and ema_short < ema_long
        vol_ok = vol > vol_sma20 * VOLUME_MULTIPLIER
        
        # Check exit
        if pos_type != 0:
            pnl_pct = (close - entry_price) / entry_price if pos_type == 1 else (entry_price - close) / entry_price
            exit_reason = None
            if pnl_pct >= TAKE_PROFIT_PCT: exit_reason = "TP"
            elif pnl_pct <= -STOP_LOSS_PCT: exit_reason = "SL"
            elif pos_type == 1 and cross_down: exit_reason = "REVERSAL"
            elif pos_type == -1 and cross_up: exit_reason = "REVERSAL"
            
            if exit_reason:
                exit_price = close * (1 - SLIPPAGE) if pos_type == 1 else close * (1 + SLIPPAGE)
                gross_pnl_pct = (exit_price - entry_price) / entry_price if pos_type == 1 else (entry_price - exit_price) / entry_price
                
                # Fee calculation (leverage applies to position size)
                trade_value = balance * LEVERAGE
                fee_cost = trade_value * FEE * 2 # Entry and Exit
                
                net_pnl = (trade_value * gross_pnl_pct) - fee_cost
                balance += net_pnl
                
                trade_history.append({"reason": exit_reason, "pnl": net_pnl, "pnl_pct": gross_pnl_pct, "entry": entry_price, "exit": exit_price, "type": "LONG" if pos_type == 1 else "SHORT"})
                pos_type = 0
                equity_curve.append(balance)
        
        # Check entry
        if pos_type == 0 and adx > 25.0:
            if bullish and rsi > RSI_BUY_MIN and vol_ok:
                pos_type = 1
                entry_price = close * (1 + SLIPPAGE)
            elif bearish and rsi < RSI_SELL_MAX and vol_ok:
                pos_type = -1
                entry_price = close * (1 - SLIPPAGE)

    # Print Report
    print(f"Total Trades: {len(trade_history)}")
    if len(trade_history) > 0:
        wins = [t for t in trade_history if t['pnl'] > 0]
        win_rate = len(wins) / len(trade_history) * 100
        
        returns = pd.Series(equity_curve).pct_change().dropna()
        sharpe = (returns.mean() / returns.std() * np.sqrt(1000)) if returns.std() != 0 else 0
        
        peak = pd.Series(equity_curve).cummax()
        drawdown = (pd.Series(equity_curve) - peak) / peak
        max_dd = drawdown.min() * 100
        
        print(f"Total PnL: {balance - INITIAL_BALANCE:.2f} USDT")
        print(f"Win Rate: {win_rate:.2f}%")
        print(f"Sharpe Ratio: {sharpe:.2f}")
        print(f"Max Drawdown: {max_dd:.2f}%")
        
        sorted_trades = sorted(trade_history, key=lambda x: x['pnl'])
        print("\nWorst 3 Trades:")
        for t in sorted_trades[:3]:
            print(f"  {t['type']} | Entry: {t['entry']:.2f} | Exit: {t['exit']:.2f} | Reason: {t['reason']} | PnL: {t['pnl']:.2f} USDT")
            
        print("\nBest 3 Trades:")
        for t in sorted_trades[-3:]:
            print(f"  {t['type']} | Entry: {t['entry']:.2f} | Exit: {t['exit']:.2f} | Reason: {t['reason']} | PnL: {t['pnl']:.2f} USDT")

if __name__ == "__main__":
    run_backtest()
