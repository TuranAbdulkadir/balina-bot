import asyncio
import logging
from decimal import Decimal
import sys
import os

# Ensure the paths are correct
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from execution.engine import ExecutionEngine
from config.settings import load_config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("Panic")

async def force_close():
    cfg = load_config()
    engine = ExecutionEngine(cfg)
    try:
        logger.info("🚨 INITIATING EMERGENCY PROTOCOL 🚨")
        
        # 1. CANCEL ALL ORDERS
        logger.info(">> Canceling all open limits...")
        await engine.rest.delete_signed("/fapi/v1/allOpenOrders", {"symbol": "BTCUSDT"})
        
        # 2. CHECK POSITIONS
        logger.info(">> Fetching open positions...")
        positions = await engine.rest.get_signed("/fapi/v2/positionRisk", {"symbol": "BTCUSDT"})
        
        has_pos = False
        if isinstance(positions, list):
            for p in positions:
                amt = float(p.get("positionAmt", "0"))
                if amt != 0:
                    has_pos = True
                    logger.info(f"FATAL: Found open position of {amt} BTCUSDT.")
                    side = "BUY" if amt < 0 else "SELL"
                    logger.info(f">> Forcing {side} at MARKET for {abs(amt)}...")
                    await engine.emergency_market_exit(side, Decimal(str(abs(amt))))
                    logger.info(">> Market execute success.")
        
        if not has_pos:
            logger.info(">> No open positions found. Threat neutralized.")
            
    except Exception as e:
        logger.error(f"Panic Sequence Error: {e}")
    finally:
        await engine.session.close()

if __name__ == "__main__":
    asyncio.run(force_close())
