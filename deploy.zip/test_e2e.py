import asyncio
import multiprocessing
import unittest
from unittest.mock import patch, AsyncMock
from core.logger_factory import get_logger
import sys
import os

# Insert MOCK Environment Variables before configs are imported to bypass sys.exit(1)
os.environ["BINANCE_API_KEY"] = "mock"
os.environ["BINANCE_ED25519_PRIVATE_KEY"] = "mock"
os.environ["TG_TOKEN"] = "mock"
os.environ["TG_USER_ID"] = "mock"

from main import main, brain_worker

from main import main, brain_worker
from network.telegram import TelegramPanicHandler
from network.http_client import BinanceRestClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] TEST: %(message)s")
logger = get_logger("TEST")

class TestE2ESimulation(unittest.IsolatedAsyncioTestCase):
    @patch('main.setup_event_loop')
    @patch('main.BinanceRestClient')
    @patch('network.ws_client.BinanceWsClient.connect_and_listen')
    @patch('storage.database.SQLiteStore.init_db')
    async def test_emergency_shutdown(self, mock_db, mock_ws, mock_rest_cls, mock_setup_loop):
        # Prevent winloop from crashing the IsolatedAsyncioTestCase event loop
        mock_setup_loop.return_value = None
        
        # 1. Mocking REST Data
        mock_rest = AsyncMock()
        mock_rest.post_signed.return_value = {"code": 200, "msg": "success"}
        mock_rest.get_signed.return_value = {"code": 200, "msg": "success"}
        mock_rest.delete_signed.return_value = {"code": 200, "msg": "success"}
        mock_rest.get_depth_snapshot.return_value = {
            "lastUpdateId": 12345, 
            "bids": [["50000", "1.0"]], 
            "asks": [["50010", "1.0"]]
        }
        mock_rest_cls.return_value = mock_rest
        
        # 2. Mocking WS connection (Keep alive dummy)
        async def mock_ws_listen():
            while True:
                await asyncio.sleep(1)
        mock_ws.side_effect = mock_ws_listen
        
        data_queue = multiprocessing.Queue()
        signal_queue = multiprocessing.Queue()
        
        # 3. Booting the Multiprocessing Engine (Brain)
        brain_proc = multiprocessing.Process(target=brain_worker, args=(data_queue, signal_queue), daemon=True)
        brain_proc.start()

        logger.info("Test Engine booted Brain process.")

        # 4. Triggering the Smart Slicing Telegram Hook
        original_poll = TelegramPanicHandler.poll
        
        class MockSuccessException(Exception):
            pass

        async def mocked_poll(self_obj):
            """Simulates receiving '/ACILKAPAT' after 3 seconds in production."""
            await asyncio.sleep(3.0)
            logger.critical("TEST: 3 seconds elapsed. Injecting MOCK '/ACILKAPAT' Telegram Trigger!")
            
            # Intercept sys.exit with our own logic right before panic exit executes it
            with patch('sys.exit', side_effect=MockSuccessException("Panic Success")):
                try:
                    await self_obj.panic_exit()
                except MockSuccessException:
                    raise  # Re-raise to break the main loop execution

        with patch.object(TelegramPanicHandler, 'poll', new=mocked_poll):
            try:
                await main(data_queue, signal_queue)
            except MockSuccessException:
                logger.critical("TEST: Smart Slicing and Suicide confirmed. Graceful shutdown caught!")
            except Exception as e:
                logger.error(f"Test failed with unexpected exception: {e}")
                self.fail("Simulation failed!")

        # 5. Clean up sub-processes
        data_queue.put(None)
        brain_proc.join(timeout=2.0)
        if brain_proc.is_alive():
            brain_proc.terminate()
            
        logger.info("✅ E2E Simulation Phase 5 SUCCEEDED.")

if __name__ == '__main__':
    multiprocessing.set_start_method("spawn")
    unittest.main()
