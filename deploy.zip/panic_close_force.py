import asyncio
import os
import sys
import time

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from dotenv import load_dotenv
load_dotenv()

from network.http_client import BinanceRestClient

async def panic():
    print("Initiating panic sequence...")
    api_key = os.getenv("BINANCE_API_KEY")
    pk_path = os.getenv("BINANCE_ED25519_PRIVATE_KEY_PATH", "private_key.pem")
    
    if not api_key:
        print("No API Key found!")
        return
        
    client = BinanceRestClient(base_url="https://fapi.binance.com")
    
    print("Canceling all open orders...")
    try:
        res = await client.delete_signed("/fapi/v1/allOpenOrders", {"symbol": "BTCUSDT"})
        print("Cancelled orders:", res)
    except Exception as e:
        print("Error canceling orders:", e)
        
    print("Checking positions...")
    try:
        res = await client.get_signed("/fapi/v2/positionRisk", {"symbol": "BTCUSDT"})
        for pos in res:
            amt = float(pos.get("positionAmt", "0"))
            if amt != 0:
                print(f"FOUND OPEN POS: {amt} BTCUSDT")
                side = "BUY" if amt < 0 else "SELL"
                
                params = {
                    "symbol": "BTCUSDT",
                    "side": side,
                    "type": "MARKET",
                    "quantity": str(abs(amt))
                }
                out = await client.post_signed("/fapi/v1/order", params)
                print("MARKET EXIT RESULT:", out)
    except Exception as e:
        print("Error closing position:", e)
        
    await client.session.close()

if __name__ == "__main__":
    asyncio.run(panic())
