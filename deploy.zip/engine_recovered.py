import asyncio
import uuid
import aiohttp
from core.logger_factory import get_logger
from decimal import Decimal, ROUND_DOWN
from typing import Dict
from orderbook.lob import LimitOrderBook
from network.http_client import BinanceRestClient

import time

logger = get_logger("ExecutionEngine")

class ExecutionEngine:
    def __init__(self, rest_client: BinanceRestClient):
        self.rest = rest_client
        self.locks: Dict[str, asyncio.Lock] = {}
        self.toxic_flow_active: bool = False
        self.open_orders: Dict[str, dict] = {} # TTL Tracker Store
        self.position_amt: Decimal = Decimal("0") # Real-time inventory tracking hook
    def _get_lock(self, symbol: str) -> asyncio.Lock:
        if symbol not in self.locks:
            self.locks[symbol] = asyncio.Lock()
        return self.locks[symbol]
    async def recover_boot_state(self, symbol: str):
    def remove_from_tracking(self, client_order_id: str):
        """Red Team Patch: Prevents API Rate Limit Bomb by gracefully popping filled/canceled orders from Sweeper memory."""
        self.open_orders.pop(client_order_id, None)
            params = {"symbol": symbol}
    async def place_strict_maker(self, symbol: str, side: str, price: Decimal, quantity: Decimal, reduce_only: bool = False):
        """Places a strict Maker (Post-Only) Limit Order. Taker execution is blocked by GTX."""
        if self.toxic_flow_active and side == "BUY" and not reduce_only:
            logger.warning(f"EXECUTION BLOCKED: TOXIC SELL FLOW DETECTED VIA VPIN. Canceling {quantity} {side}.")
            return None

        async with self._get_lock(symbol):
            new_client_order_id = f"BALINA_{uuid.uuid4().hex}"
            params = {
                "symbol": symbol,
                "side": side, # BUY or SELL
                "type": "LIMIT",
                "timeInForce": "GTX", # Post-Only (Maker) strict guarantee
                "quantity": str(quantity.quantize(Decimal('0.001'), rounding=ROUND_DOWN)),
                "price": str(price.quantize(Decimal('0.01'), rounding=ROUND_DOWN)),
                "newClientOrderId": new_client_order_id
            }
            if reduce_only:
                params["reduceOnly"] = "true"

            try:
                res = await self.rest.post_signed("/fapi/v1/order", params)
                logger.info(f"Strict Maker Order {side} {quantity} at {price} placed: {res.get('orderId')}")

                # Phase 9: Save for TTL validation
                if res and "clientOrderId" in res:
                    self.open_orders[new_client_order_id] = {
                        "symbol": symbol,
                        "timestamp": time.time(),
                        "side": side
                    }
        try:
            async with self._get_lock(symbol):
                new_client_order_id = f"BALINA_{uuid.uuid4().hex[:28]}"
            params = {
                "symbol": symbol,
                "side": side,
                "type": "LIMIT",
                "timeInForce": "GTX",
                "quantity": str(quantity.quantize(Decimal('0.001'), rounding=ROUND_DOWN)),
                "price": str(price.quantize(Decimal('0.1'), rounding=ROUND_DOWN)),
                "newClientOrderId": new_client_order_id
            }
            if reduce_only:
                params["reduceOnly"] = "true"

            try:
                res = await self.rest.post_signed("/fapi/v1/order", params)
                logger.info(f"Strict Maker Order {side} {quantity} at {price} placed: {res.get('orderId')}")

                if res and "clientOrderId" in res:
                    self.open_orders[new_client_order_id] = {
                        "symbol": symbol,
                        "timestamp": time.time(),
                        "side": side,
                        "quantity": quantity,
                        "is_exit": reduce_only
                    }
                return res
            except (asyncio.TimeoutError, aiohttp.ClientError):
                logger.error(f"Blind Timeout on {new_client_order_id}.")
                asyncio.create_task(self._reconcile_timeout_order(symbol, new_client_order_id))
                return None
            except Exception as e:
                # PLAN B: If GTX rejected (post-only violation), fall back to MARKET if reduce_only.
                if "would immediately match" in str(e).lower() or reduce_only:
                    logger.warning(f"GTX REJECTED! Falling back to MARKET order for emergency exit.")
                    market_params = {
                        "symbol": symbol, "side": side, "type": "MARKET",
                        "quantity": str(quantity.quantize(Decimal('0.001'), rounding=ROUND_DOWN))
                    }






































































                if side == "SELL":
                    visible_liquidity_at_best = Decimal(str(lob.state.bids.get(float(best_price), 0.0)))
                else:
                    visible_liquidity_at_best = Decimal(str(lob.state.asks.get(float(best_price), 0.0)))

                # Fix: Hard floor slice to prevent infinite small API loops exceeding rate limit during low-liq dumps
                safe_slice = max(Decimal("0.050"), visible_liquidity_at_best * Decimal("0.10"))
                chunk_qty = min(remaining_qty, safe_slice)

                new_client_order_id = f"BALINA_{uuid.uuid4().hex[:28]}"
                params = {
                    "symbol": symbol,
                    "side": side,
                    "type": "MARKET",
                    "quantity": str(chunk_qty.quantize(Decimal('0.001'), rounding=ROUND_DOWN)),
                    "newClientOrderId": new_client_order_id
                }

                try:
                    await self.rest.post_signed("/fapi/v1/order", params)
                    logger.info(f"Smart Slice Executed: {chunk_qty} {side} at Market.")
                except (asyncio.TimeoutError, aiohttp.ClientError):
                    logger.error(f"Smart Slice Blind Timeout on {new_client_order_id}.")
                    asyncio.create_task(self._reconcile_timeout_order(symbol, new_client_order_id))
                except Exception as e:
                    logger.error(f"Smart Slice Order Failed: {e}")

                remaining_qty -= chunk_qty

                if remaining_qty > Decimal("0"):
                    await asyncio.sleep(0.010) # Safe yield
            logger.info("Smart Slicing Exit Sequence Completed.")

    async def _reconcile_timeout_order(self, symbol: str, orig_client_order_id: str):
        await asyncio.sleep(0.5)
        try:
            params = {
                "symbol": symbol,
                "origClientOrderId": orig_client_order_id
            }
            res = await self.rest.get_signed("/fapi/v1/order", params)
            if "status" in res:
                if res["status"] in ("NEW", "PARTIALLY_FILLED", "FILLED"):
                    logger.info(f"RECON RELIEF: Order {orig_client_order_id} active locally over Remote node!")
                else:
                    logger.warning(f"RECON DROP: Order {orig_client_order_id} safely discarded (Status: {res['status']})")
        except Exception as e:
            logger.error(f"Reconciliation FAILED for blind order {orig_client_order_id}: {e}")

    async def stale_order_sweeper(self):
        logger.info("Stale Order Sweeper initialized.")
        while True:
            try:
                now = time.time()
                stale_ids = []
                for client_oid, order_info in list(self.open_orders.items()):
                    if now - order_info["timestamp"] >= 15.0:
                        stale_ids.append(client_oid)

                for stale_oid in stale_ids:
                    info = self.open_orders.pop(stale_oid, None)
                    if info:
                        logger.warning(f"TTL EXPIRED (500ms+): Canceling stale {info['side']} order ID: {stale_oid}")
                        try:
                            await self.rest.delete_signed("/fapi/v1/order", {
                                "symbol": info["symbol"],
                                "origClientOrderId": stale_oid
                            })
                        except Exception as e:
                            logger.error(f"Failed to drop stale order {stale_oid}: {e}")

            except Exception as e:
                logger.error(f"Sweeper fault: {e}")
            await asyncio.sleep(0.050)

    async def dust_sweeper_task(self):
        logger.info("Dust Sweeper Task initialized. Running every 12 hours.")
        while True:
            await asyncio.sleep(12 * 3600)
                            if is_exit:
                                logger.critical(f"🚨 EXIT ORDER FAILED TO FILL IN 250ms! ENGAGING MARKET FALLBACK (IOC) for {info['quantity']} {info['symbol']}")
                                asyncio.create_task(self.emergency_market_exit(info["symbol"], info["quantity"], info["side"]))
                            else:
                                logger.warning(f"Fırsat Kaçtı: Entry limit order {stale_oid} canceled. Returning to idle.")
                        except Exception as e:
                            logger.error(f"Failed to drop stale order {stale_oid}: {e}")
                                    "price": str(limit_price.quantize(Decimal('0.01'), rounding=ROUND_DOWN)),
            except Exception as e:
                logger.error(f"Sweeper fault: {e}")
            await asyncio.sleep(0.020)
                                await self.rest.post_signed("/fapi/v1/order", params)
    async def dust_sweeper_task(self):
        logger.info("Dust Sweeper Task initialized. Running every 12 hours.")
        while True:
            await asyncio.sleep(12 * 3600)
            try:
                res = await self.rest.get_signed("/fapi/v2/positionRisk")
                for pos in res:
                    if isinstance(pos, dict):
                        posAmt = Decimal(str(pos.get("positionAmt", "0")))
                        notional = Decimal(str(pos.get("notional", "0")))
                                    "timeInForce": "GTC",
                        if abs(notional) > Decimal("0") and abs(notional) < Decimal("5"):
                            logger.warning(f"DUST
                                    "newClientOrderId": new_client_order_id
                                }
                                await self.rest.post_signed("/fapi/v1/order", params)
            except Exception as e:
                logger.error(f"Dust sweeper faulted: {e}")
                                # 1% slippage tolerance on limits
                                limit_price = base_price * Decimal("1.01") if side == "BUY" else base_price * Decimal("0.99")
        """Phase 20: Fetch Live Commission Rates (BNB Discount Awareness)"""
                                new_client_order_id = f"BALINA_{uuid.uuid4().hex[:28]}"
                                params = {
                                    "symbol": pos["symbol"],
                                    "side": side,
                                    "type": "LIMIT",
                                    "timeInForce": "GTC",
                                    "price": str(limit_price.quantize(Decimal('0.01'), rounding=ROUND_DOWN)),
                                    "quantity": str(abs(posAmt).quantize(Decimal('0.001'), rounding=ROUND_DOWN)),
                                    "newClientOrderId": new_client_order_id
                                }
                                await self.rest.post_signed("/fapi/v1/order", params)
            except Exception as e:
                logger.error(f"Dust sweeper faulted: {e}")
            except Exception as e:
    async def commission_rate_task(self, symbol: str):
        """Phase 20: Fetch Live Commission Rates (BNB Discount Awareness)"""
        logger.info("Live Commission Rate Sync initialized.")
        from core.mathematics import FeeMath
        while True:
            try:
                res = await self.rest.get_signed("/fapi/v1/commissionRate", {"symbol": symbol})
                if res and "makerCommissionRate" in res:
                    new_maker = Decimal(str(res["makerCommissionRate"]))
                    new_taker = Decimal(str(res["takerCommissionRate"]))
