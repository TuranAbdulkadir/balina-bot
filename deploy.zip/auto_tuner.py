import time
import json
import logging
from decimal import Decimal
import requests
import asyncio
import os

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] AutoTuner: %(message)s')

CONFIG_FILE = "dynamic_config.json"

def get_recent_volatility():
    # Fetch recent 1m candles from Binance to measure exact market speed
    url = "https://fapi.binance.com/fapi/v1/klines?symbol=BTCUSDT&interval=1m&limit=30"
    try:
        data = requests.get(url, timeout=10).json()
        highs = [float(k[2]) for k in data]
        lows = [float(k[3]) for k in data]
        ranges = [h - l for h, l in zip(highs, lows)]
        avg_range = sum(ranges) / len(ranges)
        return avg_range
    except Exception as e:
        logging.error(f"Failed to fetch volatility: {e}")
        return 30.0

def optimize_parameters():
    avg_range = get_recent_volatility()
    logging.info(f"📊 Market Analysis Complete. Average 1m True Range: ${avg_range:.2f}")
    
    # ── BAYESIAN-INSPIRED GRID SCALING ──
    # If 1m candles move by $50, the grid step should be wider (e.g. $40).
    # If 1m candles move by $15, the grid step should be tighter (e.g. $15).
    
    optimal_tp_target = max(15.0, min(60.0, avg_range * 0.8))
    
    # Dynamic Z-Threshold: If market is explosive, wait for higher Z.
    # Base is 0.05. Explosive market gets up to 0.15.
    optimal_z = 0.05 + (avg_range / 100.0) * 0.10
    optimal_z = max(0.04, min(0.20, optimal_z))
    
    new_config = {
        "dynamic_z_threshold": round(optimal_z, 4),
        "tp_target": round(optimal_tp_target, 2),
        "last_updated": time.time()
    }
    
    with open(CONFIG_FILE, "w") as f:
        json.dump(new_config, f)
        
    logging.info(f"⚙️ PARAMETERS OPTIMIZED & DEPLOYED -> Z-Score: {optimal_z:.4f} | Grid TP Spread: ${optimal_tp_target:.2f}")

if __name__ == "__main__":
    logging.info("🧠 Auto-Tuner AI Initialized. Autonomous optimization loop starting...")
    while True:
        try:
            optimize_parameters()
        except Exception as e:
            logging.error(f"Auto-Tuner encountered an error: {e}")
        time.sleep(300) # Re-optimize every 5 minutes
