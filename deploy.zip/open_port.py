import oci

key_path = '/home/ubuntu/balina_bot/oracle.pem'
config = {
    'user': 'ocid1.user.oc1..aaaaaaaai4f4hxatemb2hgq7ljw6o36vcdbsgj5uie4w657e6tlbfxl5rtga',
    'fingerprint': 'f9:87:50:4d:36:9f:4e:96:2b:03:d0:c1:d7:ee:7c:11',
    'tenancy': 'ocid1.tenancy.oc1..aaaaaaaa6cpc6th6uhqxsqm6ycbd6ath3bjlon7b56mqdyer5lex3nets7ja',
    'region': 'eu-frankfurt-1',
    'key_file': key_path
}

network = oci.core.VirtualNetworkClient(config)
comp = config['tenancy']
sls = network.list_security_lists(comp).data

for sl in sls:
    rules = list(sl.ingress_security_rules)
    already = any(
        r.tcp_options and r.tcp_options.destination_port_range and r.tcp_options.destination_port_range.min == 8000
        for r in rules if r.tcp_options
    )
    if already:
        print('Port 8000 already open in', sl.display_name)
        continue
    rules.append(oci.core.models.IngressSecurityRule(
        protocol='6', source='0.0.0.0/0', is_stateless=False,
        tcp_options=oci.core.models.TcpOptions(
            destination_port_range=oci.core.models.PortRange(min=8000, max=8000)
        )
    ))
    network.update_security_list(sl.id, oci.core.models.UpdateSecurityListDetails(ingress_security_rules=rules))
    print('OPENED port 8000 in', sl.display_name)
