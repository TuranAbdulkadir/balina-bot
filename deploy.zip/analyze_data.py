import pandas as pd
import glob
import sys

files = glob.glob("/home/ubuntu/balina_bot/core/data_lake/*.parquet")
if not files:
    print("No data lake files found.")
    sys.exit(0)

latest_file = max(files)
df = pd.read_parquet(latest_file)

print(f"--- DATA QUALITY AUDIT ({latest_file}) ---")
print(f"Total Ticks Recorded: {len(df)}")
# check if min/max exists
if len(df) == 0:
    print("Empty dataframe.")
    sys.exit(0)
    
print(f"Time Range (Seconds): {df['timestamp'].max() - df['timestamp'].min():.2f}")
print("========================================")
print("1. Z-SCORE QUALITY:")
print(f"   Min: {df['zscore'].min():.4f} | Max: {df['zscore'].max():.4f} | StdDev: {df['zscore'].std():.4f}")
print(f"   Zero Value %: {(df['zscore'] == 0).mean() * 100:.2f}%")
print("========================================")
print("2. VPIN QUALITY:")
print(f"   Min: {df['vpin'].min():.4f} | Max: {df['vpin'].max():.4f} | StdDev: {df['vpin'].std():.4f}")
print("========================================")
print("3. OBI QUALITY:")
print(f"   Min: {df['obi'].min():.4f} | Max: {df['obi'].max():.4f} | StdDev: {df['obi'].std():.4f}")
print(f"   Zero Value %: {(df['obi'] == 0).mean() * 100:.2f}%")
print("========================================")
print("4. MID-PRICE LATENCY & SPREAD:")
spread = df["best_ask"] - df["best_bid"]
print(f"   Avg Spread: {spread.mean():.4f} | Max Spread: {spread.max():.4f}")
time_range = df["timestamp"].max() - df["timestamp"].min()
if time_range > 0:
    print(f"   Tick Velocity: {len(df) / time_range:.2f} ticks/sec")
