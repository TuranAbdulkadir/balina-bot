import oci
import os
import time

def execute_hard_reboot():
    key_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "oracle.pem")
    config = {
        "user": "ocid1.user.oc1..aaaaaaaai4f4hxatemb2hgq7ljw6o36vcdbsgj5uie4w657e6tlbfxl5rtga",
        "fingerprint": "f9:87:50:4d:36:9f:4e:96:2b:03:d0:c1:d7:ee:7c:11",
        "tenancy": "ocid1.tenancy.oc1..aaaaaaaa6cpc6th6uhqxsqm6ycbd6ath3bjlon7b56mqdyer5lex3nets7ja",
        "region": "eu-frankfurt-1",
        "key_file": key_path
    }

    try:
        oci.config.validate_config(config)
        print("[SUCCESS] Oracle OCI Configuration Validated.")
        compute_client = oci.core.ComputeClient(config)
        
        # Free Tier resources are usually provisioned at the root root compartment or child. We fetch cross-compartment if possible, but tenancy usually works.
        compartment_id = config["tenancy"]
        instances = compute_client.list_instances(compartment_id).data
        
        if not instances:
            print("[WARN] No instances found in root compartment. Trying to find child compartments...")
            identity = oci.identity.IdentityClient(config)
            compartments = identity.list_compartments(compartment_id).data
            for comp in compartments:
                comp_instances = compute_client.list_instances(comp.id).data
                instances.extend(comp_instances)

        for inst in instances:
            print(f"> Found Instance: {inst.display_name} | State: {inst.lifecycle_state}")
            
            if inst.lifecycle_state == inst.LIFECYCLE_STATE_RUNNING:
                print(f"  --> Hardware is RUNNING. Injecting STOP...")
                compute_client.instance_action(inst.id, "STOP")
                print("  --> Signal sent successfully. Machine is stopping.")
            
            elif inst.lifecycle_state == inst.LIFECYCLE_STATE_STOPPED:
                print(f"  --> Hardware is STOPPED. Injecting WAKE/START signal...")
                compute_client.instance_action(inst.id, "START")
                print("  --> Signal sent successfully. Machine is booting.")
                
        print("[PROCESS COMPLETE] OCI hardware interventions executed.")

    except Exception as e:
        print(f"[FATAL OCI ERROR] Could not execute commands: {e}")

if __name__ == "__main__":
    execute_hard_reboot()
