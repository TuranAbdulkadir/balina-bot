import os
env_path = os.path.expanduser('~/balina_bot/.env')
with open(env_path, 'r') as f:
    lines = f.readlines()
new_lines = []
for line in lines:
    if line.startswith('TG_TOKEN') or line.startswith('TG_USER_ID'):
        continue
    new_lines.append(line)
new_lines.append('TG_TOKEN="8715820712:AAG83jLKOrnieWY5-kS-sH5ISI1c-NxoT1k"\n')
new_lines.append('TG_USER_ID="1151983697"\n')
with open(env_path, 'w') as f:
    f.writelines(new_lines)
print('Config updated!')
